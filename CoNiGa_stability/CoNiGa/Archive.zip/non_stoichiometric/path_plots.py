import sys
sys.path.append("/home/anjana/Dropbox/bin")
sys.path.append("/Users/anjanatalapatra/Dropbox/bin")
from numpy import loadtxt, arange, nan, linspace
from scipy import interpolate
from plot_settings import save_fig_size, set_legend, set_lines_labels
from pylab import plot, xlabel, ylabel, xlim
from matplotlib.pyplot import figure, savefig, tight_layout
from matplotlib import rcParams



GGA = loadtxt('burgers_energy.dat')


x_GGA = GGA[:, 0]
y_GGA = GGA[:, 1]

f_GGA = interpolate.interp1d(
    x_GGA, y_GGA, kind='cubic', axis=-1, copy=True, bounds_error=True, fill_value=nan)
xnew = arange(0, 1.5, 0.05)
ynew = f_GGA(xnew)

bain_heusler = loadtxt('ca_energy.dat')
x_h_bain = bain_heusler[:, 0]
y_h_bain = bain_heusler[:, 1]
x_bain_new = arange(1.068432717, 1.21, 0.01)
f_bain =  interpolate.interp1d(
    x_h_bain, y_h_bain, kind='cubic', axis=-1, copy=True, bounds_error=True, fill_value=nan)
y_bain_new =f_bain(x_bain_new)


# # --------------------------------------------------------------------------------------------------------------#
fig = figure(figsize=(6,4))

ax = fig.add_subplot(111)

ln1 = ax.plot(xnew, ynew, 'b-o', label='Burgers')
ax2 = ax.twiny()
ln2 = ax2.plot(x_bain_new, y_bain_new, 'r-s', label='Bain')
lns = ln1 + ln2  # + ln3
labs = [l.get_label() for l in lns]
leg = ax.legend(lns, labs, loc=1)
leg.get_frame().set_visible(False)
ax.set_xlabel("Reaction coordinate (Burgers path)", fontsize=12)
ax.set_ylabel(r"Energy[meV/f.u]", fontsize=12)
ax2.set_xlabel("c/a ratio (Bain path)", fontsize=12)
#save_fig_size('CNG_non_stoic', 6, 4, 'eps')
#save_fig_size('CNG_non_stoic', 6, 4, 'pdf')
savefig('figure_10.pdf',transparent='true')

# --------------------------------------------------------------------------------------------------------------#