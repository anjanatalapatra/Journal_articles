import sys
sys.path.append("/home/anjana/Dropbox/bin")
sys.path.append("/Users/anjanatalapatra/Dropbox/bin")

from numpy import loadtxt, arange, nan, linspace
from scipy import interpolate
from plot_settings import save_fig_size, set_legend, set_lines_labels
from pylab import plot, xlabel, ylabel, ylim
from matplotlib.pyplot import figure
import matplotlib.pyplot as plt

mag_bain = loadtxt('mag_disorder_bain_new.dat')
nmag_bain = loadtxt('non_magnetic_bain.dat')
mag_burger = loadtxt('mag_disorder_burgers.dat')



f, ((ax1, ax3), (ax5, ax7), (ax9, ax11)) = plt.subplots(3, 2, sharex='col', sharey='row')

# # # --------------------------------------------------------------------------------------------------------------#
#ax1 = fig.add_subplot(111)
ln1 = ax1.plot(mag_burger[:,0], mag_burger[:,1], 'r-o', label='Burger')
ax2 = ax1.twiny()
ln2 = ax2.plot(mag_bain[:,0], mag_bain[:,1], 'b-s', label='Bain')
#ax1.set_ylabel("Energy[meV/f.u]", fontsize=16)
ax2.set_xlabel("c/a ratio (Bain path)", fontsize=16)
ax2.set_xticklabels([0.8,0.9,1.0,1.1,1.2,1.3,1.4,1.5,1.6],fontsize=12)
#ax1.set_xlabel("Reaction coordinate (Burgers path)", fontsize=16)
#ax1.set_xticklabels([0.0,0.2,0.4,0.6,0.8,1.0,1.2,1.4,1.6],fontsize=12)
ax1.set_xlim(0.0,1.4)
ax1.get_xaxis().set_visible(False)
#ax1.set_yticklabels([-100,-50,0,50,100,150,200],fontsize=12)
lns = ln1 + ln2  # + ln3
labs = [l.get_label() for l in lns]
leg = ax1.legend(lns, labs, loc=1)
leg.get_frame().set_visible(False)

ln3 = ax3.plot(mag_burger[:,0], mag_burger[:,1], 'r-o', label='Burger')
ax4 = ax3.twiny()
ln4 = ax4.plot(mag_bain[:,0], mag_bain[:,1], 'b-s', label='Bain')
#ax3.set_ylabel("Energy[meV/f.u]", fontsize=16)
ax4.set_xlabel("c/a ratio (Bain path)", fontsize=16)
ax4.set_xticklabels([0.8,0.9,1.0,1.1,1.2,1.3,1.4,1.5,1.6],fontsize=12)
#ax3.set_xlabel("Reaction coordinate (Burgers path)", fontsize=16)
ax3.set_xticklabels([0.0,0.2,0.4,0.6,0.8,1.0,1.2,1.4,1.6],fontsize=12)
ax3.set_xlim(0.0,1.4)
ax3.get_xaxis().set_visible(False)
lns = ln3 + ln4  # + ln3
labs = [l.get_label() for l in lns]
leg = ax1.legend(lns, labs, loc=1)
leg.get_frame().set_visible(False)

ln5 = ax5.plot(mag_burger[:,0], mag_burger[:,1], 'r-o', label='Burger')
ax6 = ax5.twiny()
ln6 = ax6.plot(mag_bain[:,0], mag_bain[:,1], 'b-s', label='Bain')
ax5.set_ylabel("Energy[meV/f.u]", fontsize=16)
#ax6.set_xlabel("c/a ratio (Bain path)", fontsize=16)
ax6.set_xticklabels([0.8,0.9,1.0,1.1,1.2,1.3,1.4,1.5,1.6],fontsize=12)
#ax5.set_xlabel("Reaction coordinate (Burgers path)", fontsize=16)
ax5.set_xticklabels([0.0,0.2,0.4,0.6,0.8,1.0,1.2,1.4,1.6],fontsize=12)
ax5.set_xlim(0.0,1.4)
ax6.get_xaxis().set_visible(False)
#ax1.set_yticklabels([-100,-50,0,50,100,150,200],fontsize=12)
lns = ln5 + ln6  # + ln3
labs = [l.get_label() for l in lns]
leg = ax1.legend(lns, labs, loc=1)
leg.get_frame().set_visible(False)


ln7 = ax7.plot(mag_burger[:,0], mag_burger[:,1], 'r-o', label='Burger')
ax8 = ax7.twiny()
ln8 = ax8.plot(mag_bain[:,0], mag_bain[:,1], 'b-s', label='Bain')
#ax7.set_ylabel("Energy[meV/f.u]", fontsize=16)
#ax8.set_xlabel("c/a ratio (Bain path)", fontsize=16)
ax8.set_xticklabels([0.8,0.9,1.0,1.1,1.2,1.3,1.4,1.5,1.6],fontsize=12)
#ax7.set_xlabel("Reaction coordinate (Burgers path)", fontsize=16)
ax7.set_xticklabels([0.0,0.2,0.4,0.6,0.8,1.0,1.2,1.4,1.6],fontsize=12)
ax7.set_xlim(0.0,1.4)
ax8.get_xaxis().set_visible(False)
#ax1.set_yticklabels([-100,-50,0,50,100,150,200],fontsize=12)
lns = ln7 + ln8  # + ln3
labs = [l.get_label() for l in lns]
leg = ax1.legend(lns, labs, loc=1)
leg.get_frame().set_visible(False)

ln9 = ax9.plot(mag_burger[:,0], mag_burger[:,1], 'r-o', label='Burger')
ax10 = ax9.twiny()
ln10 = ax10.plot(mag_bain[:,0], mag_bain[:,1], 'b-s', label='Bain')
#ax9.set_ylabel("Energy[meV/f.u]", fontsize=16)
#ax10.set_xlabel("c/a ratio (Bain path)", fontsize=16)
ax10.set_xticklabels([0.8,0.9,1.0,1.1,1.2,1.3,1.4,1.5,1.6],fontsize=12)
ax9.set_xlabel("Reaction coordinate (Burgers path)", fontsize=16)
ax9.set_xticklabels([0.0,0.2,0.4,0.6,0.8,1.0,1.2,1.4,1.6],fontsize=12)
ax9.set_xlim(0.0,1.4)
#ax1.set_yticklabels([-100,-50,0,50,100,150,200],fontsize=12)
lns = ln9 + ln10  # + ln3
labs = [l.get_label() for l in lns]
leg = ax1.legend(lns, labs, loc=1)
leg.get_frame().set_visible(False)


ln11 = ax11.plot(mag_burger[:,0], mag_burger[:,1], 'r-o', label='Burger')
ax12 = ax11.twiny()
ln12 = ax12.plot(mag_bain[:,0], mag_bain[:,1], 'b-s', label='Bain')
#ax11.set_ylabel("Energy[meV/f.u]", fontsize=16)
#ax12.set_xlabel("c/a ratio (Bain path)", fontsize=16)
ax12.set_xticklabels([0.8,0.9,1.0,1.1,1.2,1.3,1.4,1.5,1.6],fontsize=12)
ax11.set_xlabel("Reaction coordinate (Burgers path)", fontsize=16)
ax11.set_xticklabels([0.0,0.2,0.4,0.6,0.8,1.0,1.2,1.4,1.6],fontsize=12)
ax11.set_xlim(0.0,1.4)
#ax1.set_yticklabels([-100,-50,0,50,100,150,200],fontsize=12)
lns = ln11 + ln12  # + ln3
labs = [l.get_label() for l in lns]
leg = ax1.legend(lns, labs, loc=1)
leg.get_frame().set_visible(False)
f.subplots_adjust(hspace=0)
f.subplots_adjust(wspace=0)
save_fig_size('mag_disorder_all', 10, 10, 'pdf')
# # # --------------------------------------------------------------------------------------------------------------#