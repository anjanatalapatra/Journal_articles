import sys
sys.path.append("/home/anjanat/Dropbox/bin")
sys.path.append("/Users/anjanatalapatra/Dropbox/bin")
from numpy import loadtxt, arange, nan, linspace
from scipy import interpolate
from plot_settings import save_fig_size, set_legend, set_lines_labels
from pylab import plot, xlabel, ylabel, xlim, ylim
from matplotlib.pyplot import figure


GGA = loadtxt('non_magnetic_burgers.dat')

x_GGA = GGA[:, 0]
y_GGA = GGA[:, 1] 

f_GGA = interpolate.interp1d(
    x_GGA, y_GGA, kind='cubic', axis=-1, copy=True, bounds_error=True, fill_value=nan)
xnew = arange(0, 1.55, 0.1)
ynew = f_GGA(xnew)
# --------------------------------------------------------------------------------------------------------------#

# --------------------------------------------------------------------------------------------------------------#
fig = figure()
bain_heusler = loadtxt('non_magnetic_bain.dat')
x_h_bain = bain_heusler[:, 0]
y_h_bain = bain_heusler[:, 1]
f_bain= interpolate.interp1d(
    x_h_bain, y_h_bain, kind='cubic', axis=-1, copy=True, bounds_error=True, fill_value=nan)
x_bain = arange(0.84, 1.52, 0.04)
print x_bain
y_bain = f_bain(x_bain)
print y_bain
ax = fig.add_subplot(111)
ln1 = ax.plot(xnew, ynew , 'b-o', label='Burgers path')
# ln3 = ax.plot(x_2D, (y_2D - y_2D[0]), 'r-s', label='2D Burgers path')
ax2 = ax.twiny()
ln2 = ax2.plot(x_h_bain, y_h_bain , 'r-s', label='Bain')
lns = ln1 + ln2  # + ln3
labs = [l.get_label() for l in lns]
leg = ax.legend(lns, labs, loc=1)
leg.get_frame().set_visible(False)
ax.set_xlabel("Reaction coordinate (Burgers)", fontsize=16)
ax.set_ylabel(r"Energy[meV/f.u]", fontsize=16)
ax2.set_xlabel("c/a ratio (Bain path)", fontsize=16)
ylim(-180,180)
save_fig_size('CNG_nm', 6, 4, 'eps')
save_fig_size('CNG_nm', 6, 4, 'pdf')
# --------------------------------------------------------------------------------------------------------------#
