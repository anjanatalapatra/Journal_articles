import sys
sys.path.append("/home/anjana/Dropbox/bin")
from numpy import loadtxt, arange, nan, linspace, sqrt
from scipy import interpolate
from plot_settings import save_fig_size, set_legend, set_lines_labels
from pylab import plot, xlabel, ylabel, xlim
from matplotlib.pyplot import figure


mag_1_1_bain = loadtxt('ca_energy_mag_1.1.dat')
mag_0_9_bain = loadtxt('ca_energy_mag_0.9.dat')
mag_0_7_bain = loadtxt('ca_energy_mag_0.7.dat')
mag_0_5_bain = loadtxt('ca_energy_mag_0.5.dat')
mag_0_3_bain = loadtxt('ca_energy_mag_0.3.dat')
mag_0_1_bain = loadtxt('ca_energy_mag_0.1.dat')
mag_1_0_bain = loadtxt('ca_energy.dat')
E0 = -5.67150125
x_1_1 = (mag_1_1_bain[:,0])/sqrt(2)
x = (mag_0_9_bain[:,0])/sqrt(2)
y_1_1 = (mag_1_1_bain[:,1] - E0)*1000
y_1_0 = (mag_1_0_bain[:,1] - E0)*1000
y_0_9 = (mag_0_9_bain[:,1] - E0)*1000
y_0_7 = (mag_0_7_bain[:,1] - E0)*1000
y_0_5 = (mag_0_5_bain[:,1] - E0)*1000
y_0_3 = (mag_0_3_bain[:,1] - E0)*1000
y_0_1 = (mag_0_1_bain[:,1] - E0)*1000

mag_1_1_burger = loadtxt('burgers_energy_mag_1.1.dat')
mag_0_9_burger = loadtxt('burgers_energy_mag_0.9.dat')
#mag_0_7_burger = loadtxt('burger_energy_mag_0.7.dat')
#mag_0_5_burger = loadtxt('burger_energy_mag_0.5.dat')
#mag_0_3_burger = loadtxt('burger_energy_mag_0.3.dat')
#mag_0_1_burger = loadtxt('burger_energy_mag_0.1.dat')
mag_1_0_burger = loadtxt('burgers_energy_mag_1.0.dat')
B_E0 = -3.066137750000000217
x_b = (mag_0_9_burger[:,0])
print mag_1_1_burger[:,1]
y_1_1_b = (mag_1_1_burger[:,1] - B_E0)
print y_1_1_b
y_1_0_b = (mag_1_0_burger[:,1] - B_E0)
y_0_9_b = (mag_0_9_burger[:,1] - B_E0)
#y_0_7_b = (mag_0_7_burger[:,1] - B_E0)*1000
#y_0_5_b = (mag_0_5_burger[:,1] - B_E0)*1000
#y_0_3_b = (mag_0_3_burger[:,1] - B_E0)*1000
#y_0_1_b = (mag_0_1_burger[:,1] - B_E0)*1000

fig = figure()
ax = fig.add_subplot(111)
ln1 = ax.plot(x_1_1,y_1_1, 'b-o',x, y_1_0, 'k-o',x, y_0_9, 'g-o',x, y_0_7, 'c-o',x, y_0_5, 'y-o', x, y_0_3, 'r-o',x, y_0_1, 'm-o', )
#ax2 = ax.twiny()
#ln2 = ax2.plot(x_b,y_1_1_b, 'b--o',x_b, y_1_0_b, 'k--o',x_b, y_0_9_b, 'g--o')#,x_b, y_0_7_b, 'c-o',x_b, y_0_5_b, 'y-o', x_b, y_0_3_b, 'r-o',x_b, y_0_1_b, 'm-o', )
ax.set_xlabel('Reaction coordinate (Bain path)', fontsize=16)
ax.set_ylabel('Energy[meV/f.u]', fontsize=16)
#ax2.set_xlabel('Reaction coordinate (Burgers path)', fontsize=16)
set_legend('1.1', '1.0', '0.9', '0.7','0.5','0.3','0.1',0)
save_fig_size('CNG_mag_bain_path', 10, 7, 'eps')
save_fig_size('CNG_mag_bain_path', 10, 7, 'pdf')
# --------------------------------------------------------------------------------------------------------------#
# figure()
# inverse_GGA = loadtxt('GGA_inverse_CoNiGa_burgers_energy.dat')
# x_i_GGA = inverse_GGA[:, 0]
# y_i_GGA = inverse_GGA[:, 1]
# f_i_GGA = interpolate.interp1d(
#     x_i_GGA, y_i_GGA, kind='cubic', axis=-1, copy=True, bounds_error=True, fill_value=nan)
# xnew = arange(0, 1.45, 0.05)
# ynew = f_GGA(xnew)
# yi_GGA = f_i_GGA(xnew)
# plot(xnew, (ynew - ynew[0]) * 1000, 'b-o', xnew, (
#     yi_GGA - yi_GGA[0]) * 1000, 'm-s')
# # ylim(-40, 40)
# xlim(0, 1.45)
# xlabel('Reaction coordinate (Burgers path)', fontsize=16)
# ylabel('Energy[meV/f.u]', fontsize=16)
# set_legend('Heusler', 'Inverse heusler', 0)
# save_fig_size('CNG__heusler_inverse_heusler', 8, 7, 'eps')
# save_fig_size('CNG__heusler_inverse_heusler', 8, 7, 'pdf')
# # --------------------------------------------------------------------------------------------------------------#
# fig = figure()
# bain_heusler = loadtxt('heusler_ca_energy.dat')
# x_h_bain = bain_heusler[:, 0]
# y_h_bain = bain_heusler[:, 1]
# ax = fig.add_subplot(111)
# ln1 = ax.plot(xnew, (ynew - ynew[0]) * 1000, 'b-o', label='Burgers path')
# ax.plot(1.1, -170.724, 'b-o')
# # ln3 = ax.plot(x_2D, (y_2D - y_2D[0]), 'r-s', label='2D Burgers path')
# ax2 = ax.twiny()
# ln2 = ax2.plot(x_h_bain, (y_h_bain - y_h_bain[
#                9]) * 4000, 'r-s', label='Bain path')
# lns = ln1 + ln2  # + ln3
# labs = [l.get_label() for l in lns]
# leg = ax.legend(lns, labs, loc=1)
# leg.get_frame().set_visible(False)
# ax.set_xlabel("Reaction coordinate (Burgers path)", fontsize=16)
# ax.set_ylabel(r"Energy[meV/f.u]", fontsize=16)
# ax2.set_xlabel("c/a ratio (Bain path)", fontsize=16)
# save_fig_size('CNG__burger_bain', 8, 7, 'eps')
# save_fig_size('CNG__burger_bain', 8, 7, 'pdf')
# # --------------------------------------------------------------------------------------------------------------#
# fig = figure()
# D2_inv = loadtxt('GGA_inverse_CoNiGa_burgers_energy_2D.dat')
# x_i_2D = linspace(0, 1, num=50)
# y_i_2D = D2_inv[:, 2]
# ax = fig.add_subplot(111)
# ln1 = ax.plot(x_i_2D, (y_i_2D - y_i_2D[
#               0]) * 1.26, 'r-s', label='Inverse Heusler-CoNiGa')
# ln2 = ax.plot(x_2D, (y_2D - y_2D[0]), 'b-o', label='Heusler-CoNiGa')
# lns = ln1 + ln2
# labs = [l.get_label() for l in lns]
# leg = ax.legend(lns, labs, loc=1)
# leg.get_frame().set_visible(False)
# ax.set_xlabel("Reaction coordinate (Burgers path)", fontsize=16)
# ax.set_ylabel(r"Energy[meV/f.u]", fontsize=16)
# ax2.set_xlabel("c/a ratio (Bain path)", fontsize=16)
# save_fig_size('CNG_2D_burger', 8, 7, 'eps')
# save_fig_size('CNG_2D_burger', 8, 7, 'pdf')
# # --------------------------------------------------------------------------------------------------------------#

# figure()
# pvdos_L21 = loadtxt('CNG_pvdos_L21.out')
# nu_L21 = pvdos_L21[:, 0]
# L21_pvdos_Co = pvdos_L21[:, 1] + pvdos_L21[:, 2]
# L21_pvdos_Ga = pvdos_L21[:, 3]
# L21_pvdos_Ni = pvdos_L21[:, 4]
# L21_vdos = L21_pvdos_Co + L21_pvdos_Ni + L21_pvdos_Ga
# plot(nu_L21, L21_pvdos_Co, 'b--', nu_L21, L21_pvdos_Ni,
#      'c-', nu_L21, L21_pvdos_Ga, 'r-.', nu_L21, L21_vdos, 'k:.')
# set_legend('Co', 'Ni', 'Ga', 'total', 2)
# set_lines_labels(16, [2, 2, 2, 2], [2])
# save_fig_size('pvdos_L21', 8, 7, 'pdf')
# save_fig_size('pvdos_L21', 8, 7, 'eps')
# # --------------------------------------------------------------------------------------------------------------#
# fig = figure()
# bain_inverse = loadtxt('inverse_ca_energy.dat')
# D2_inv = loadtxt('GGA_inverse_CoNiGa_burgers_energy_2D.dat')
# x_i_bain = bain_inverse[:, 0]
# y_i_bain = bain_inverse[:, 1]
# x_i_2D = linspace(0, 1, num=50)
# y_i_2D = D2_inv[:, 2]
# ax = fig.add_subplot(111)
# ln1 = ax.plot(xnew, (yi_GGA - yi_GGA[
#               0]) * 1000, 'b-o', label='Inverse Burgers path')
# ax2 = ax.twiny()
# ln2 = ax2.plot(x_i_bain, (y_i_bain - y_i_bain[
#                10]) * 4000, 'r-s', label='Inverse Bain path')
# # ln3 = ax.plot(x_i_2D, (y_i_2D - y_i_2D[
# #              0]) * 1.26, 'r-s', label='2D Burgers path')
# lns = ln1 + ln2  # + ln3
# labs = [l.get_label() for l in lns]
# leg = ax.legend(lns, labs, loc=2)
# leg.get_frame().set_visible(False)
# ax.set_xlabel("Reaction coordinate (Burgers path)", fontsize=16)
# ax.set_ylabel(r"Energy[meV/f.u]", fontsize=16)
# ax2.set_xlabel("c/a ratio (Bain path)", fontsize=16)
# save_fig_size('CNG_inverse_burger_bain', 8, 7, 'eps')
# save_fig_size('CNG_inverse_burger_bain', 8, 7, 'pdf')
# --------------------------------------------------------------------------------------------------------------#
