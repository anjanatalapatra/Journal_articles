from numpy import loadtxt
from matplotlib.pyplot import figure, savefig



fig = figure()
bain_mag = loadtxt('mag_bain.dat')
burger_mag = loadtxt('mag_burger.dat')
x_bain = bain_mag[:, 0]
mag_bain = bain_mag[:, 1]
ax = fig.add_subplot(111)
ax.plot(x_bain, mag_bain, 'r-o', label='Bain path')
ax.legend(loc=1)
ax.set_xticks([0.8,1.0, 1.3,1.4,1.6])
#ax.set_xticklabels([r'$\alpha$',r'$\beta$',r'$\gamma$',r'$\delta$',r'$\epsilon$','F','G','H','I'])
ax.set_xticklabels([r'$\alpha$',r'$\beta$',r'$\gamma$',r'$\delta$',r'$\epsilon$'])
ax.set_ylabel(r"$\Delta $ m /f.u", fontsize=12)
ax.set_xlabel("c/a ratio (Bain path)", fontsize=12)
savefig('mag_burger_bain.png', dpi=fig.dpi)