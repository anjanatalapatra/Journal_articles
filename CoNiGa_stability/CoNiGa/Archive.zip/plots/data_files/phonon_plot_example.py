
import matplotlib.pyplot as plt
from numpy import loadtxt, linspace
# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------##
freq = loadtxt('L21_eigenfreq.out') * 10 ** (-12)
n = len(freq[:, 0])
x = linspace(0, 1, n)
y = linspace(0, 0, n)
# # ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------##
plt.figure(figsize=(4, 6))
for i in range(len(freq[0])):
	plt.plot(x, freq[:, i],'o', markersize=2.5, markeredgecolor='none' ,color='blue')
plt.plot(x,y,'k--',linewidth=1)	
plt.locator_params(nbins=4)
plt.xlabel('$[\\xi,\\xi,0]$', fontsize=16)
plt.ylabel('Frequency (THz)', fontsize=16)
plt.xlim(0,1)
plt.savefig('phonon_dispersion.jpg')
