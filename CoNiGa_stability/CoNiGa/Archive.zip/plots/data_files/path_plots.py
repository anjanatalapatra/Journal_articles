import sys
sys.path.append("/home/anjana/Dropbox/bin")
sys.path.append("/Users/Gothmog/Dropbox/bin")
from numpy import loadtxt, arange, nan, linspace
from scipy import interpolate
from plot_settings import save_fig_size, set_legend, set_lines_labels
from pylab import plot, xlabel, ylabel, xlim
from matplotlib.pyplot import figure, savefig, tight_layout
from matplotlib import rcParams



GGA = loadtxt('GGA_heusler_CoNiGa_burgers_energy.dat')
D2 = loadtxt('GGA_heusler_CoNiGa_burgers_energy_2D.dat')
LDA = loadtxt('LDA_heusler_CoNiGa_burgers_energy.dat')

x_GGA = GGA[:, 0]
y_GGA = GGA[:, 1] / 2
x_LDA = LDA[:, 0]
y_LDA = LDA[:, 1]
x_2D = linspace(0, 1, num=50)
y_2D = D2[:, 2]

f_GGA = interpolate.interp1d(
    x_GGA, y_GGA, kind='cubic', axis=-1, copy=True, bounds_error=True, fill_value=nan)
f_LDA = interpolate.interp1d(
    x_LDA, y_LDA, kind='cubic', axis=-1, copy=True, bounds_error=True, fill_value=nan)
xnew = arange(0, 1.55, 0.05)
ynew = f_GGA(xnew)
# yLDA = f_LDA(xnew)
# plot(xnew, (ynew - ynew[0]) * 1000, 'b-o', xnew, (yLDA - yLDA[0]) * 1000, 'r-s')
# xlabel('Reaction coordinate (Burgers path)', fontsize=16)
# ylabel('Energy[meV/f.u]', fontsize=16)
# set_legend('GGA', 'LDA', 2)
# save_fig_size('CNG_1D_burger_path', 8, 7, 'eps')
# save_fig_size('CNG_1D_burger_path', 8, 7, 'pdf')
# # --------------------------------------------------------------------------------------------------------------#
# figure()
# inverse_GGA = loadtxt('GGA_inverse_CoNiGa_burgers_energy.dat')
# x_i_GGA = inverse_GGA[:, 0]
# y_i_GGA = inverse_GGA[:, 1]
# f_i_GGA = interpolate.interp1d(
#     x_i_GGA, y_i_GGA, kind='cubic', axis=-1, copy=True, bounds_error=True, fill_value=nan)
# xnew = arange(0, 1.45, 0.05)
# ynew = f_GGA(xnew)
# yi_GGA = f_i_GGA(xnew)
# plot(xnew, (ynew - ynew[0]) * 1000, 'b-o', xnew, (
#     yi_GGA - yi_GGA[0]) * 1000, 'm-s')
# # ylim(-40, 40)
# xlim(0, 1.45)
# xlabel('Reaction coordinate (Burgers path)', fontsize=16)
# ylabel('Energy[meV/f.u]', fontsize=16)
# set_legend('Heusler', 'Inverse heusler', 0)
# save_fig_size('CNG__heusler_inverse_heusler', 8, 7, 'eps')
# save_fig_size('CNG__heusler_inverse_heusler', 8, 7, 'pdf')
# # --------------------------------------------------------------------------------------------------------------#
# fig = figure(figsize=(8, 6))
# bain_heusler = loadtxt('heusler_ca_energy.dat')
# x_h_bain = bain_heusler[:, 0]
# y_h_bain = bain_heusler[:, 1]
# ax = fig.add_subplot(111)
# ln1 = ax.plot(xnew, (ynew - ynew[0]) * 1000, 'r-o', label='BURGER')
# ax.plot(1.1, -170.724, 'r-o')
# # ln3 = ax.plot(x_2D, (y_2D - y_2D[0]), 'r-s', label='2D Burgers path')
# ax2 = ax.twiny()
# ln2 = ax2.plot(x_h_bain, (y_h_bain - y_h_bain[10]) * 4000, 'b-s', label='BAIN')
# lns = ln1 + ln2  # + ln3
# labs = [l.get_label() for l in lns]
# leg = ax.legend(lns, labs, loc=1)
# text1, text2 = leg.get_texts()
# text1.set_color('yellow')
# text2.set_color('white')
# leg.get_frame().set_visible(False)
# ax.spines['bottom'].set_color('white')
# ax.spines['bottom'].set_color('white')
# ax.spines['top'].set_color('white')
# ax.spines['left'].set_color('white')
# ax.spines['right'].set_color('white')
# ax.xaxis.label.set_color('white')
# ax.yaxis.label.set_color('white')
# ax2.xaxis.label.set_color('white')
# ax.tick_params(axis='x', colors='white')
# ax2.tick_params(axis='x', colors='white')
# ax.tick_params(axis='y', colors='white')
# ax.set_xlabel("REACTION COORDINATE (BURGERS PATH)", fontsize=16)
# ax.set_ylabel(r"ENERGY [meV/f.u]", fontsize=16)
# ax2.set_xlabel("c/a RATIO (BAIN PATH)", fontsize=16)
# save_fig_size('CNG_burger_bain', 8, 7, 'eps')
# save_fig_size('CNG_burger_bain', 8, 7, 'pdf')
#savefig('temp.png', transparent=True)
#savefig('temp.png')

# # --------------------------------------------------------------------------------------------------------------#
fig = figure(figsize=(6,4))
bain_heusler = loadtxt('heusler_ca_energy.dat')
x_h_bain = bain_heusler[:, 0]
y_h_bain = bain_heusler[:, 1]
ax = fig.add_subplot(111)
ln1 = ax.plot(xnew, (ynew - ynew[0]) * 1000, 'b-o', label='Burgers path')
ax.plot(1.1, -170.724, 'b-o')
# ln3 = ax.plot(x_2D, (y_2D - y_2D[0]), 'r-s', label='2D Burgers path')
ax2 = ax.twiny()
ln2 = ax2.plot(x_h_bain, (y_h_bain - y_h_bain[10]) * 4000, 'r-s', label='Bain path')
lns = ln1 + ln2  # + ln3
labs = [l.get_label() for l in lns]
leg = ax.legend(lns, labs, loc=1)
leg.get_frame().set_visible(False)
ax.set_xlabel("Reaction coordinate (Burgers path)", fontsize=12)
ax.set_ylabel(r"Energy[meV/f.u]", fontsize=12)
ax2.set_xlabel("c/a ratio (Bain path)", fontsize=12)
ax.set_ylim(-200,200)
save_fig_size('CNG_burger_bain', 6, 4, 'eps')
save_fig_size('CNG_burger_bain', 6, 4, 'pdf')
tight_layout()
savefig('figure_1.pdf',transparent='true')
# --------------------------------------------------------------------------------------------------------------#
# fig = figure()
# D2_inv = loadtxt('GGA_inverse_CoNiGa_burgers_energy_2D.dat')
# x_i_2D = linspace(0, 1, num=50)
# y_i_2D = D2_inv[:, 2]
# ax = fig.add_subplot(111)
# #ln1 = ax.plot(x_i_2D, (y_i_2D - y_i_2D[
#  #             0]) * 1.26, 'r-s', label='Inverse Heusler-CoNiGa')
# ln2 = ax.plot(x_2D, (y_2D - y_2D[0]), 'b-o', label='Heusler-CoNiGa')
# #lns = ln1 + ln2
# #labs = [l.get_label() for l in lns]
# #leg = ax.legend(lns, labs, loc=1)
# #leg.get_frame().set_visible(False)
# ax.set_xlabel("Reaction coordinate (Burgers path)", fontsize=16)
# ax.set_ylabel(r"Energy[meV/f.u]", fontsize=16)
# #ax2.set_xlabel("c/a ratio (Bain path)", fontsize=16)
# save_fig_size('CNG_2D_burger', 4, 3.5, 'eps')
# save_fig_size('CNG_2D_burger', 4, 3.5, 'pdf')
# # --------------------------------------------------------------------------------------------------------------#

# figure()
# pvdos_L21 = loadtxt('CNG_pvdos_L21.out')
# nu_L21 = pvdos_L21[:, 0]
# L21_pvdos_Co = pvdos_L21[:, 1] + pvdos_L21[:, 2]
# L21_pvdos_Ga = pvdos_L21[:, 3]
# L21_pvdos_Ni = pvdos_L21[:, 4]
# L21_vdos = L21_pvdos_Co + L21_pvdos_Ni + L21_pvdos_Ga
# plot(nu_L21, L21_pvdos_Co, 'b--', nu_L21, L21_pvdos_Ni,
#      'c-', nu_L21, L21_pvdos_Ga, 'r-.', nu_L21, L21_vdos, 'k:.')
# set_legend('Co', 'Ni', 'Ga', 'total', 2)
# set_lines_labels(16, [2, 2, 2, 2], [2])
# save_fig_size('pvdos_L21', 8, 7, 'pdf')
# save_fig_size('pvdos_L21', 8, 7, 'eps')
# # --------------------------------------------------------------------------------------------------------------#
# fig = figure()
# bain_inverse = loadtxt('inverse_ca_energy.dat')
# D2_inv = loadtxt('GGA_inverse_CoNiGa_burgers_energy_2D.dat')
# x_i_bain = bain_inverse[:, 0]
# y_i_bain = bain_inverse[:, 1]
# x_i_2D = linspace(0, 1, num=50)
# y_i_2D = D2_inv[:, 2]
# ax = fig.add_subplot(111)
# ln1 = ax.plot(xnew, (yi_GGA - yi_GGA[
#               0]) * 1000, 'b-o', label='Inverse Burgers path')
# ax2 = ax.twiny()
# ln2 = ax2.plot(x_i_bain, (y_i_bain - y_i_bain[
#                10]) * 4000, 'r-s', label='Inverse Bain path')
# # ln3 = ax.plot(x_i_2D, (y_i_2D - y_i_2D[
# #              0]) * 1.26, 'r-s', label='2D Burgers path')
# lns = ln1 + ln2  # + ln3
# labs = [l.get_label() for l in lns]
# leg = ax.legend(lns, labs, loc=2)
# leg.get_frame().set_visible(False)
# ax.set_xlabel("Reaction coordinate (Burgers path)", fontsize=16)
# ax.set_ylabel(r"Energy[meV/f.u]", fontsize=16)
# ax2.set_xlabel("c/a ratio (Bain path)", fontsize=16)
# save_fig_size('CNG_inverse_burger_bain', 8, 7, 'eps')
# save_fig_size('CNG_inverse_burger_bain', 8, 7, 'pdf')
# --------------------------------------------------------------------------------------------------------------#
fig = figure(figsize=(6,4))
bain_SQS = loadtxt('CNG_SQS_bain.dat')
burger_SQS = loadtxt('CNG_SQS_burgers.dat')
x_SQS_bain = bain_SQS[:, 0]
y_SQS_bain = bain_SQS[:, 1]
x_SQS_burger = burger_SQS[:, 0]
y_SQS_burger = burger_SQS[:, 1]
ax = fig.add_subplot(111)
ln1 = ax.plot(x_SQS_burger, y_SQS_burger, 'b-o', label='Burgers path')
ax2 = ax.twiny()
ln2 = ax2.plot(x_SQS_bain, y_SQS_bain, 'r-s', label='Bain path')
lns = ln1 + ln2  # + ln3
labs = [l.get_label() for l in lns]
leg = ax.legend(lns, labs, loc=1)
leg.get_frame().set_visible(False)
ax.set_ylim(-100, 80)
ax.set_xlabel("Reaction coordinate (Burgers path)", fontsize=12)
ax.set_ylabel(r"Energy[meV/f.u]", fontsize=12)
ax2.set_xlabel("c/a ratio (Bain path)", fontsize=12)
#save_fig_size('SQS_burger_bain', 6, 4, 'eps')
#save_fig_size('SQS_burger_bain', 6, 4, 'pdf',)
tight_layout()
savefig('figure_8.pdf', transparent=True)
# --------------------------------------------------------------------------------------------------------------#