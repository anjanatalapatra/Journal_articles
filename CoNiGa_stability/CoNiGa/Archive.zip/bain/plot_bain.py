import sys
from numpy import loadtxt, sqrt
import matplotlib.pyplot as plt

bain_heusler = loadtxt('ca_energy.dat')
x = bain_heusler[:, 0]/sqrt(2)
y = bain_heusler[:, 1]
z = bain_heusler[:,2]

plt.plot(x, y, 'b-o')
plt.xlabel('c/a ratio')
plt.ylabel('Energy[eV/atom]')
plt.savefig('bain.png',bbox_inches='tight')

fig = plt.figure()
plt.plot(x, z, 'b-o')
plt.xlabel('c/a ratio')
plt.ylabel('Magnetization')
plt.savefig('bain_mag.png',bbox_inches='tight')
