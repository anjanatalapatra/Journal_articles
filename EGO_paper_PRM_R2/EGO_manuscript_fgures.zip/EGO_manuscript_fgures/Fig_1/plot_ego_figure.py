import numpy as np
import matplotlib
from sklearn.gaussian_process import GaussianProcess
from matplotlib import pyplot as plt
from plot_settings import save_fig_size
from matplotlib.patches import ConnectionPatch
np.random.seed(1)

font = {'family': 'sans-serif',
        'weight': 'bold',
        'size': 12}

matplotlib.rc('font', **font)
matplotlib.rcParams['axes.linewidth'] = 0.1

label_size = 12
matplotlib.rcParams['xtick.labelsize'] = label_size
matplotlib.rcParams['ytick.labelsize'] = label_size


def f(x):
    """The function to predict."""
    return x**2 * np.sin(x) * np.cos(x)


X = np.atleast_2d([0.25, 3.5, 7.75, 8.]).T
y = f(X).ravel()
x = np.atleast_2d(np.linspace(0, 8, 1000)).T
gp = GaussianProcess(corr='cubic', theta0=1e-2, thetaL=1e-4, thetaU=1e-1,
                     random_start=100)
gp.fit(X, y)
y_pred, MSE = gp.predict(x, eval_MSE=True)
sigma = np.sqrt(MSE)
bestValue = np.amax(y, axis=0)
err = (bestValue - y_pred) / sigma
EI = (y_pred + 1.96 * sigma) - bestValue
index_max = max(xrange(len(EI)), key=EI.__getitem__)


fig, (ax1,ax3) = plt.subplots(1, 2, sharey=True)
lns1 = ax1.plot(x, f(x), '-', color='darkgreen', label=u'$f(x)$')
lns2 = ax1.plot(X, y, '.', color='darkgreen', markersize=10, label=u'Observations')
lns3 = ax1.plot(x, y_pred, '--', color='darkgreen', label=u'Prediction')
lns4 = ax1.fill(np.concatenate([x, x[::-1]]),
                np.concatenate([y_pred - 1.9600 * sigma,
                                (y_pred + 1.9600 * sigma)[::-1]]),
                alpha=.6, fc='darkgreen', ec='None', label='95\% confidence interval')

ax1.set_xlabel('$x$')
ax1.set_ylabel('function $f(x)$ to optimize', color='darkgreen', fontweight='bold')
ax1.tick_params(axis='y', colors='darkgreen')
ax1.set_ylim(-50, 120)
plt.xlim(0, 8)
props = dict(boxstyle='round', facecolor='white', alpha=0.5)
ax2 = ax1.twinx()
lns5 = ax2.plot(x, EI, 'r-', label='Expected Improvement')
lns6 = ax2.plot(x[724], EI[724], 'r-s', markersize=10, label='New Experiment')
# ax2.set_ylabel('Expected Improvement', color='r', fontweight='bold')
print x[724]
ax2.tick_params(axis='y', colors='r')
ax2.yaxis.set_ticklabels([])
ax1.text(0.15, 0.92, 'Next sample \n point', transform=ax1.transAxes, fontsize=12,
        verticalalignment='top', bbox=props)
#ax1.annotate('Next sample \n point', xy=(5.77, 100), xytext=(2, 82),
#            arrowprops=dict(color='red', width=0.2), bbox=props
#            )
ax1.arrow(4, 105, 1.5, 0, linestyle='--', color='r')
#lns = lns1 + lns2 + lns3 + lns4 + lns5 + lns6
#labs = [l.get_label() for l in lns]
ax2.set_ylim(-20, 90)
#ax2.legend(lns, labs, loc='upper left')
ax1.set_facecolor('blanchedalmond')
#save_fig_size('ego1', 3, 2.5, 'pdf')


X = np.atleast_2d([0.25, 3.5, 5.7977978, 7.75, 8.]).T
y = f(X).ravel()
gp.fit(X, y)
y_pred, MSE = gp.predict(x, eval_MSE=True)
sigma = np.sqrt(MSE)
bestValue = np.amax(y, axis=0)
err = (bestValue - y_pred) / sigma
EI = (y_pred + 1.96 * sigma) - bestValue
index_max = max(xrange(len(EI)), key=EI.__getitem__)

#fig, ax1 = plt.subplots()
lns1 = ax3.plot(x, f(x), '-', color='darkgreen', label=u'$f(x)$')

lns2 = ax3.plot(X, y, '.', color='darkgreen',  markersize=10, label=u'Observations')
lns3 = ax3.plot(x, y_pred, '--', color='darkgreen',  label=u'Prediction')
lns4 = ax3.fill(np.concatenate([x, x[::-1]]),
                np.concatenate([y_pred - 1.9600 * sigma,
                                (y_pred + 1.9600 * sigma)[::-1]]),
                alpha=.6, fc='darkgreen', ec='None', label='95 confidence interval')
ax3.set_xlabel('$x$')
# ax3.set_ylabel('function $f(x)$ to optimize', color='darkgreen', fontweight='bold')
ax3.tick_params(axis='y', colors='darkgreen')
ax3.set_ylim(-50, 120)
ax3.arrow(1.8, 112, 1.5, 0, linestyle='--', color='r')
ax3.text(1.5, 0.96, 'Next sample \n point', transform=ax1.transAxes, fontsize=12,
        verticalalignment='top', bbox=props)

#ax3.arrow(1.8, 78, 0, -43, linestyle='--', color='r')
plt.xlim(0, 8)
ax4 = ax3.twinx()
lns5 = ax4.plot(x, EI, 'r-', label='Expected Improvement')
lns6 = ax4.plot(x[226], EI[226], 'r-s', markersize=10, label='New Experiment')
print EI[226]
ax4.set_ylabel('Expected Improvement', color='r', fontweight='bold')
ax4.tick_params(axis='y', colors='r')
lns = lns1 + lns2 + lns3 + lns4 + lns5 + lns6
labs = [l.get_label() for l in lns]
ax2.set_ylim(-20, 90)
# ax2.legend(lns, labs, loc='upper right')
ax3.set_facecolor('blanchedalmond')
matplotlib.pyplot.subplots_adjust(wspace=0.05)
fig.legend(lns, labs, loc='lower left', bbox_to_anchor=(0.2, 1.001), ncol=2)
# con = ConnectionPatch(xyA=(0.5,50), xyB=(2.5,50), coordsA="data", coordsB="data",
#                       axesA=ax1, axesB=ax3, arrowstyle="-|>", color="blue")
# ax1.add_artist(con)
con = ConnectionPatch(xyA=(7.5,40), xyB=(0.5,26), coordsA="data", coordsB="data",
                      axesA=ax2, axesB=ax4, arrowstyle="simple", color="blue")
ax2.add_artist(con)
save_fig_size('ego', 7, 3.0, 'pdf')
