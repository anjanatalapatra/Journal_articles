#! /usr/bin/env python
"""
 Module for running and control of EGO
"""

__author__ = "Anjana Talapatra (anjanatalapatra@tamu.edu)"
__version__ = "0.1$"
__date__ = "$Date: May 2016 $"
__copyright__ = "Copyright (c) 2016 Anjana Talapatra"
__license__ = "Python"

import sys
sys.path.append(r'C:\Users\Anjana\Dropbox\bin')
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from plot_settings import *
import matplotlib as mpl
from matplotlib import colors


font = {'family': 'sans-serif',
        'weight': 'bold',
        'size': 12}


label_size = 12
mpl.rcParams['xtick.labelsize'] = label_size
mpl.rcParams['ytick.labelsize'] = label_size

matplotlib.rc('font', **font)
matplotlib.rcParams['axes.linewidth'] = 0.1

color_palette =['darkviolet','darkcyan']
ax = subplot(111)
data = np.loadtxt('N_20_summary_29f.dat')
sns.swarmplot(x=data[:,1],y=data[:,2],size=1, palette=color_palette,edgecolor='none')
plot([-5,25],[80,80],'k--',linewidth=0.75)
#x =[2,5,10,15,20]
labels = [  'BMA$_1$','F$_{all}$']
ax.set_xticklabels(labels)
plt.yticks(np.arange(0, 160, 40.0))
plt.ylim(0,120)
plt.xlabel('Feature sets')
plt.ylabel('Number of calculations')
ax.set_facecolor('blanchedalmond')
save_fig_size('K_max_N_20_29f_violinplot',3,2.5,'pdf')