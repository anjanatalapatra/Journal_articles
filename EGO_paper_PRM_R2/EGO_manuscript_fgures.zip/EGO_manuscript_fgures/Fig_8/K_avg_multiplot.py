#! /usr/bin/env python
"""
 Module for running and control of EGO
"""

__author__ = "Anjana Talapatra (anjanatalapatra@tamu.edu)"
__version__ = "0.1$"
__date__ = "$Date: May 2016 $"
__copyright__ = "Copyright (c) 2016 Anjana Talapatra"
__license__ = "Python"


import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from matplotlib import colors
from plot_settings import *

font = {'family': 'sans-serif',
        'weight': 'bold',
        'size': 12}


label_size = 12
mpl.rcParams['xtick.labelsize'] = label_size
mpl.rcParams['ytick.labelsize'] = label_size

matplotlib.rc('font', **font)
matplotlib.rcParams['axes.linewidth'] = 0.1

init_sets = [20]
new_x =[20,30,40,50,60,70,80,90,100]
x= [0,5,10,15,20,25,30,35,40]
#sns.set_style("white")

for i in init_sets:
	fig, ax1 = plt.subplots()
	new_x =[i,i+10,i+20,i+30,i+40,i+50,i+60,i+70,i+80]
	x= [0,5,10,15,20,25,30,35,40]
	data_1 = np.loadtxt('N{}_coeff_1.dat'.format(str(i)))
	data_2 = np.loadtxt('N{}_coeff_2.dat'.format(str(i)))
	data_3 = np.loadtxt('N{}_coeff_3.dat'.format(str(i)))
	data_4 = np.loadtxt('N{}_coeff_4.dat'.format(str(i)))
	data_5 = np.loadtxt('N{}_coeff_5.dat'.format(str(i)))
	data_6 = np.loadtxt('N{}_coeff_6.dat'.format(str(i)))
	data_7 = np.loadtxt('N{}_coeff_7.dat'.format(str(i)))
	data_8 = np.loadtxt('N{}_coeff_8.dat'.format(str(i)))
	data_9 = np.loadtxt('N{}_coeff_9.dat'.format(str(i)))
	data_10 = np.loadtxt('N{}_coeff_10.dat'.format(str(i)))

	
	p1=sns.tsplot(data=data_1,linewidth=2.0,linestyle='-', color="g")#,marker="o",markersize=6,linewidth=1.0,markeredgecolor='none')
	p2=sns.tsplot(data=data_2,linewidth=2.0, linestyle='--', color="b")#,marker="s",markersize=6,linewidth=1.0,markeredgecolor='none')
	p3=sns.tsplot(data=data_3,linewidth=2.0, marker='v',color="magenta",markersize=3)#,marker="p",markersize=6,linewidth=1.0,markeredgecolor='none')
	p4=sns.tsplot(data=data_4,linewidth=2.0, marker='p',color ='purple',markersize=3)#,marker="d",markersize=6,linewidth=1.0,markeredgecolor='none')
	p5=sns.tsplot(data=data_5,linewidth=2.0, marker='o',color="darkorange",markersize=3)#,marker="v",markersize=8,linewidth=1.0,markeredgecolor='none')
	p6=sns.tsplot(data=data_6,linewidth=2.0, marker='D',color="gray",markersize=3)#,marker="*",markersize=10,linewidth=1.0,markeredgecolor='none')
	p7=sns.tsplot(data=data_7,linewidth=2.0, marker='*',color="k",markersize=3)
	p8=sns.tsplot(data=data_8,linewidth=2.0, marker='+',color="k",markersize=3)
	p9=sns.tsplot(data=data_9,linewidth=2.0, marker='s',color="k",markersize=3)
	p10=sns.tsplot(data=data_10,linewidth=2.0, marker='P',color="k",markersize=3)
	#sns.set_style("white")
	plt.xticks(x,new_x)
	plt.xlabel('Number of Calculations')
	plt.ylabel('Model coefficient')
	plt.yticks(np.arange(0, 1.0, 0.2))
	plt.ylim(-0.05,1.0)
	plt.xlim(0,30)


	line1 = plt.Line2D((0,1),(0,0), linewidth=2.0,linestyle='-', color="g")
	line2 = plt.Line2D((0,1),(0,0), linewidth=2.0, linestyle='--', color="b")
	line3 = plt.Line2D((0,1),(0,0), linewidth=2.0, marker='v',color="magenta",markersize=3)
	line4 = plt.Line2D((0,1),(0,0), linewidth=2.0, marker='p',color ='purple',markersize=3)
	line5 = plt.Line2D((0,1),(0,0), linewidth=2.0, marker='o',color="darkorange",markersize=3)
	line6 = plt.Line2D((0,1),(0,0), linewidth=2.0, marker='D',color="gray",markersize=3)
	line7 = plt.Line2D((0,1),(0,0), linewidth=2.0, marker='*',color="k",markersize=3)
	line8 = plt.Line2D((0,1),(0,0), linewidth=2.0, marker='+',color="k",markersize=3)
	line9 = plt.Line2D((0,1),(0,0), linewidth=2.0, marker='s',color="k",markersize=3)
	line10 = plt.Line2D((0,1),(0,0), linewidth=2.0, marker='P',color="k",markersize=3)
	#plt.plot([0,38],[300,300],'r--')
	ax = plt.gca()
	ax.set_facecolor('blanchedalmond')
	handles, labels = ax.get_legend_handles_labels()
	first_legend=plt.legend([handle for i,handle in enumerate(handles) if i in display]+[line1,line2,line3,line4,line5,line6,line7,line8,line9,line10],[label for i,label in enumerate(labels) if i in display]+['$F_1$','$F_2$','$F_3$','$F_4$','$F_5$','$F_6$','$F_7$ .. $F_{10}$'],loc=1, ncol=2,fontsize=10,frameon=True)
	first_legend.get_frame().set_linewidth(0)
	first_legend.get_frame().set_facecolor('None')
	save_fig_size('N_{}_K_max_BMA_first_order_coeff'.format(str(i)),3, 2.5,'pdf')


