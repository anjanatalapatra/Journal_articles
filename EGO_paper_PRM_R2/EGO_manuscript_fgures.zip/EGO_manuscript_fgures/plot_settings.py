#!/usr/bin/env python
""" This module provides functions for controlling axes-limits, setting
fontsizes of all text elements, linewidths of all lines in the plot, paper size
of figure and finally save the figure in desired format with a tight bounding
box.
The functions provided by this module are
---------------------------------------------------
1. set_legend
2. set_lines_labels
3. set_axis_limits
4. save_fig_size
----------------------------------------------------
The main code for plotting is rendered cleaner and shorter since all parameters
are being set by the functions in this module. Good-looking, publication-quality
plots can be produced with the use of this module.
Note that to successfully import this module, it must be either in the current
working directory or in the module search path of python. The path to this
module/file may either be added permanently to the module search path or one can
add it at runtime before importing the module in the working document with the
commands:
--------------------------------------------------
import sys
sys.path.append("/home/username/wherever_it_is")
--------------------------------------------------
However, irrespective of the location of this module, the figures created are
saved in the current directory.
This module docstring can be accessed after importing by:
---------------------------------------------------
print plot_settings.__doc__
---------------------------------------------------
The function docstrings in it can be viewed , for example with:
---------------------------------------------------
print plot_settings.legend.__doc__
---------------------------------------------------
"""


#===================================
# Required modules
#===================================
from matplotlib import pyplot
from pylab import *
from matplotlib import rc
#from mpl_toolkits.mplot3d import axes3d, Axes3D
#from os import getcwd  


######################################

######################################
__author__ ='''Shriram Srinivasan, Kaarthik Sundar, Anjana Talapatra'''
__email__  ='''me.shriram@gmail.com'''
__date__  ='''July 18 2011'''
######################################

#=====================================
# Set fonts to resemble Latex fonts
#=====================================
rc('font',**{'family':'serif','serif':['Computer Modern Roman']})
rc('text', usetex=True)


#======================================
# legend function
#======================================
def set_legend(*args):
    '''creates legend, given text and location. Usage:
    set_legend('text',location_string_or_number)
    '''

    labels = []
    for i in range(0, len(args) - 1):
        labels.append(args[i])
    loc_input = args[len(args) - 1]
    #frame = args[len(args)-1]
    frame = False
    labels = tuple(labels)
    pyplot.legend(labels, loc=loc_input, frameon=frame, borderpad=0.2, numpoints=1, markerscale=0.8)

#========================================
# set_lines_labels function
#========================================
def set_lines_labels(*args):
    ''' set_lines_labels takes in 3 arguments maximum -
    FontSize,LineWidth,MarkerSize. Usage: set_lines_labels(10,[1 2],[4 5]) The
    first line in the plot has linewidth 1 and markersize 4 while the second
    line has values 2 and 5.
    '''
        
    # get handle to lines
    lines = gca().lines
        
    # get some legend properties
    leg = gca().get_legend()
    ltext  = leg.get_texts()  # all the text.Text instance in the legend
    llines = leg.get_lines()  # all the lines.Line2D instance in the legend
    
    fsize = 12  # default value
    
    if(len(args)==1): 
        fsize = args[0] # input fontsize
        
    if(len(args)==2):
        fsize = args[0]
        lw = args[1] # requested linewidths
        msize = [2]  # default value
        
    if(len(args)==3):
        fsize = args[0]
        lw = args[1]	
        msize = args[2] # requested markersizes
        
    if (len(args) != 1):
        if (len(lw)>1 or len(msize)>1): 
            number_of_lines = max(len(lw),len(msize))		
            while number_of_lines > len(lw):
                lw.append(lw[0]) 
            while len(msize)<number_of_lines:
                msize.append(msize[0])		 
        
    if (len(lw)==1 and len(msize)==1):
        number_of_lines = 1
        setp(lines,linewidth = lw[0],markersize = msize[0])
        setp(llines,linewidth = lw[0],markersize = msize[0])
    else:
        for i in range(0,number_of_lines):
            setp(lines[i],linewidth = lw[i],markersize = msize[i])
            setp(llines[i],linewidth = lw[i],markersize = msize[i])
   
    # Now setting up requested fontsizes for axis labels and ticks    
    xlabel(gca().get_xlabel(), fontsize = fsize)
    ylabel(gca().get_ylabel(), fontsize = fsize)
    title(gca().get_title(), fontsize = fsize)	
    
    # ticklabels  should be smaller than axislabels
    setp(gca().get_xticklabels(), fontsize = fsize-2)  
    setp(gca().get_yticklabels(), fontsize = fsize-2)
    

    # set fontsize for legend 
    setp(ltext, fontsize= fsize-4)    # the legend text fontsize	
        
    # Font size for text/annotation, legend set in rcParams file
    values = {'text.fontsize': fsize-1,
              #'font.size': fsize-1,
              'lines.antialiased' : True, # render lines in antialised (no jaggies)
              'text.usetex': True}
              
    # Update rcParams to reflect chosen values
    rcParams.update(values)
        

#=============================================
# set_axis_limits function
#=============================================
def set_axis_limits(a,b):
    ''' The function extends the axes limits by a% and b% respectively The
    limits are computed from the tighest limits possible (axis 'tight'). Usage:
    set_axis_limits(5,10)
    '''
    
    pyplot.axis('tight')
    xlim1, xlim2 = xlim()   
    ylim1, ylim2 = ylim()   
    a = float(a)
    b = float(b)
    xmin = (1+ a/100)*xlim1 - (a/100)*xlim2      
    xmax = (1+ a/100)*xlim2 - (a/100)*xlim1     
    ymin = (1+ b/100)*ylim1 - (b/100)*ylim2 
    ymax = (1+ b/100)*ylim2 - (b/100)*ylim1   
    r = [xmin, xmax, ymin, ymax]
    pyplot.axis(r)


#================================================
# save_fig_size function
#================================================
def save_fig_size(*args):
    ''' The function crops the figure to given size and saves it,with given
    filename. The extensions are optional arguments. Usage:
    save_fig_size('filename', width, height,'eps','pdf','png')
    '''
    

    F = pyplot.gcf()

    if len(args)<3:
        print 'save_fig_size requires at least filename, width and height'
        exit(0)
    
    F.set_size_inches(args[1],args[2])

    if len(args) == 3:
        extension = 'eps' # Default extension

    if len(args)>3:
        for i in range(3,len(args)):
            pyplot.savefig(args[0] +'.'+ args[i],bbox_inches='tight')
    
