#! /usr/bin/env python
"""
 Module for running and control of EGO
"""

__author__ = "Anjana Talapatra (anjanatalapatra@tamu.edu)"
__version__ = "0.1$"
__date__ = "$Date: May 2016 $"
__copyright__ = "Copyright (c) 2016 Anjana Talapatra"
__license__ = "Python"


import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from matplotlib import colors
from plot_settings import *
init_sets =[10]#[2,5,10,15,20]
new_x =[2,12,22,32,42,52,62,72,82]
x= [0,5,10,15,20,25,30,35,40]
#sns.set_style("white")

font = {'family' : 'sans-serif',
        'weight' : 'bold',
        'size'   : 12}

matplotlib.rc('font', **font)
matplotlib.rcParams['axes.linewidth'] = 0.1

label_size = 12
mpl.rcParams['xtick.labelsize'] = label_size 
mpl.rcParams['ytick.labelsize'] = label_size


for i in init_sets:
	
	new_x =[i,i+10,i+20,i+30,i+40,i+50,i+60,i+70,i+80]
	x= [0,5,10,15,20,25,30,35,40]
	data_1 = np.loadtxt('N{}_F1.dat'.format(str(i)))
	data_2 = np.loadtxt('N{}_F2.dat'.format(str(i)))
	data_3 = np.loadtxt('N{}_F3.dat'.format(str(i)))
	data_4 = np.loadtxt('N{}_F4.dat'.format(str(i)))
	data_5 = np.loadtxt('N{}_F5.dat'.format(str(i)))
	data_6 = np.loadtxt('N{}_F6.dat'.format(str(i)))
	data_all = np.loadtxt('N{}_F7.dat'.format(str(i)))
	data_fo = np.loadtxt('N{}_max_fo.dat'.format(str(i)))
	data_so = np.loadtxt('N{}_max_so.dat'.format(str(i)))
	# plt.figure()
	# p1=sns.tsplot(data=data_1, color="g",marker="o",markersize=3,markeredgecolor='none')
	# p2=sns.tsplot(data=data_2, color="b",marker="s",markersize=3,markeredgecolor='none')
	# p3=sns.tsplot(data=data_3, color="saddlebrown",marker="p",markersize=3,markeredgecolor='none')
	# p4=sns.tsplot(data=data_4, color ='purple',marker="d",markersize=3,markeredgecolor='none')
	# p5=sns.tsplot(data=data_5, color="darkorange",marker="v",markersize=3,markeredgecolor='none')
	# p6=sns.tsplot(data=data_6, color="gray",marker="*",markersize=3,markeredgecolor='none')
	
	# #sns.set_style("white")
	# plt.xticks(x,new_x)
	# plt.xlabel('Number of Calculations')
	# plt.ylabel('Minimum Shear Modulus (GPa)')
	# plt.ylim(5,75)
	# plt.xlim(0,38)

	# line1 = plt.Line2D((0,1),(0,0), color="g",marker="o",markersize=3,markeredgecolor='none')
	# line2 = plt.Line2D((0,1),(0,0), color="b",marker="s",markersize=3,markeredgecolor='none')
	# line3 = plt.Line2D((0,1),(0,0), color="saddlebrown",marker="p",markersize=3,markeredgecolor='none')
	# line4 = plt.Line2D((0,1),(0,0), color ='purple',marker="d",markersize=3,markeredgecolor='none')
	# line5 = plt.Line2D((0,1),(0,0), color="lime",marker="v",markersize=3,markeredgecolor='none')
	# line6 = plt.Line2D((0,1),(0,0), color="gray",marker="*",markersize=3,markeredgecolor='none')
	# plt.plot([0,38],[10.38,10.38],'k--',linewidth=0.5)
	# ax = plt.gca()
	# ax.set_axis_bgcolor('blanchedalmond')
	# matplotlib.rcParams['axes.linewidth'] = 0.1
	# handles, labels = ax.get_legend_handles_labels()
	# first_legend =plt.legend([handle for i,handle in enumerate(handles) if i in display]+[line1,line2,line3,line4,line5,line6],[label for i,label in enumerate(labels) if i in display]+['F1','F2','F3','F4','F5','F6'],ncol=2,loc=1,fontsize=10)
	# first_legend.get_frame().set_linewidth(0.1)
	# first_legend.get_frame().set_facecolor('antiquewhite')
	# save_fig_size('N_{}_G_min_single_models'.format(str(i)),3,2.5,'pdf')

	plt.figure()
	p2=sns.tsplot(data=data_2,linewidth=2.0, linestyle='--', color="b")
	p6=sns.tsplot(data=data_6,linewidth=2.0, marker='D',color="gray",markersize=3)
	p7=sns.tsplot(data=data_fo,color="dodgerblue",marker="h",markersize=3)
	p8=sns.tsplot(data=data_so,color="r",marker="|",markersize=3)

	#sns.set_style("white")
	plt.xticks(x,new_x)
	plt.xlabel('Number of Calculations')
	plt.ylabel('Min Shear Modulus (GPa)')
	plt.yticks(np.arange(0, 80, 20))
	plt.ylim(5,75)
	plt.xlim(0,38)
	line2 = plt.Line2D((0,1),(0,0), linewidth=2.0, linestyle='--', color="b")
	line6 = plt.Line2D((0,1),(0,0), linewidth=2.0, marker='D',color="gray",markersize=3)
	line7 = plt.Line2D((0,1),(0,0), color="dodgerblue",marker="h",markersize=3)
	line8 = plt.Line2D((0,1),(0,0), color="r",marker="+",markersize=3)
	plt.plot([0,38],[10.38,10.38],'k--',linewidth=0.5)
	ax = plt.gca()
	ax.set_facecolor('blanchedalmond')
	matplotlib.rcParams['axes.linewidth'] = 0.1
	handles, labels = ax.get_legend_handles_labels()
	first_legend=plt.legend([handle for i,handle in enumerate(handles) if i in display]+[line2,line6,line7,line8],[label for i,label in enumerate(labels) if i in display]+['$F_2$','$F_6$','BMA$_1$','BMA$_2$'],ncol=2,loc=1,fontsize=10) #bbox_to_anchor=(0.05, 0.05)
	first_legend.get_frame().set_linewidth(0)
	first_legend.get_frame().set_facecolor('blanchedalmond')
	save_fig_size('N_{}_G_min_BMA'.format(str(i)),3,2.5,'pdf')

	# plt.figure()
	# p2=sns.tsplot(data=data_2, color="b",marker="s",markersize=3,markeredgecolor='none')
	# pall = sns.tsplot(data=data_all,color="magenta",marker="*",markersize=3,markeredgecolor='none')
	# p7=sns.tsplot(data=data_fo,color="dodgerblue",marker="h",markersize=3,markeredgecolor='none')
	# p8=sns.tsplot(data=data_so,color="r",marker="+",markersize=3,markeredgecolor='none')

	# sns.set_style("white")
	# plt.xticks(x,new_x)
	# plt.xlabel('Number of Calculations')
	# plt.ylabel('Min Shear Modulus (GPa)')
	# plt.yticks(np.arange(0, 80, 20))
	# plt.ylim(5,75)
	# plt.xlim(0,38)
	# line2 = plt.Line2D((0,1),(0,0), color="b",marker="s",markersize=3,markeredgecolor='none')
	# lineall = plt.Line2D((0,1),(0,0), color="magenta",marker="*",markersize=3,markeredgecolor='none')
	# line7 = plt.Line2D((0,1),(0,0), color="dodgerblue",marker="h",markersize=3,markeredgecolor='none')
	# line8 = plt.Line2D((0,1),(0,0), color="r",marker="+",markersize=3,markeredgecolor='none')
	# plt.plot([0,38],[300,300],'k--',linewidth=0.5)
	# ax = plt.gca()
	# ax.set_axis_bgcolor('blanchedalmond')
	# plt.legend([handle for i,handle in enumerate(handles) if i in display]+[line2,lineall,line7,line8],[label for i,label in enumerate(labels) if i in display]+['F2','all F','BMA-$1^{st}$ order','BMA-$2^{nd}$ order'],ncol=2,loc=1,fontsize=10) #bbox_to_anchor=(0.05, 0.05)
	# save_fig_size('N_{}_G_min_all_F'.format(str(i)),3,2,'pdf')





