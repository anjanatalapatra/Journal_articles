#! /usr/bin/env python
"""
 Module for running and control of EGO
"""

__author__ = "Anjana Talapatra (anjanatalapatra@tamu.edu)"
__version__ = "0.1$"
__date__ = "$Date: May 2016 $"
__copyright__ = "Copyright (c) 2016 Anjana Talapatra"
__license__ = "Python"

import sys
sys.path.append(r'C:\Users\Anjana\Dropbox\bin')
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from plot_settings import *
import matplotlib as mpl
from matplotlib import colors


font = {'family' : 'sans-serif',
        'weight' : 'bold',
        'size'   : 12}

matplotlib.rc('font', **font)
matplotlib.rcParams['axes.linewidth'] = 0.1

label_size = 12
mpl.rcParams['xtick.labelsize'] = label_size 
mpl.rcParams['ytick.labelsize'] = label_size


#color_palette =['orangered','forestgreen','palevioletred','dodgerblue','chocolate']
color_palette =['green','blue','saddlebrown','purple','darkorange','gray']
# f, ((ax1, ax2, ax3), (ax4, ax5, ax6),) = plt.subplots(2, 3,sharex='col', sharey='row')
# sns.violinplot(x=data1[:,0],y=data1[:,2],bw=0.1, linewidth=0.2, ax=ax1, palette=color_palette)
# ax1.plot([-5,25],[80,80],'r--',linewidth=0.75)
# ax2.plot([-5,25],[80,80],'r--',linewidth=0.75)
# ax3.plot([-5,25],[80,80],'r--',linewidth=0.75)
# ax4.plot([-5,25],[80,80],'r--',linewidth=0.75)
# ax5.plot([-5,25],[80,80],'r--',linewidth=0.75)
# ax6.plot([-5,25],[80,80],'r--',linewidth=0.75)
# sns.violinplot(x=data2[:,0],y=data2[:,2],bw=0.1, linewidth=0.2,ax=ax2, palette=color_palette)
# sns.violinplot(x=data3[:,0],y=data3[:,2],bw=0.1, linewidth=0.2,ax=ax3, palette=color_palette)
# sns.violinplot(x=data4[:,0],y=data4[:,2],bw=0.1, linewidth=0.2,ax=ax4, palette=color_palette)
# sns.violinplot(x=data5[:,0],y=data5[:,2],bw=0.1, linewidth=0.2,ax=ax5, palette=color_palette)
# sns.violinplot(x=data6[:,0],y=data6[:,2],bw=0.1, linewidth=0.2,ax=ax6, palette=color_palette)
# #x =[2,5,10,15,20]
# #labels = [ 'N=2','N=5','N=10','N=15','N=20']
# x =[2,5,10,15,20]
# labels = [ 'N=2','N=5','N=10','N=15','N=20']
# ax4.set_xticklabels(labels)
# ax5.set_xticklabels(labels)
# ax6.set_xticklabels(labels)
# plt.subplots_adjust(hspace = .1)
# plt.subplots_adjust(wspace = .1)
# ax1.set_ylim(-20,160)
# ax2.set_ylim(-20,160)
# ax3.set_ylim(-20,160)
# ax4.set_ylim(-20,160)
# ax5.set_ylim(-20,160)
# ax6.set_ylim(-20,160)
# ax1.text(0.01,140,'F1')
# ax2.text(0.01,140,'F2')
# ax3.text(0.01,140,'F3')
# ax4.text(0.01,140,'F4')
# ax5.text(0.01,140,'F5')
# ax6.text(0.01,140,'F6')
# # ax1.set_facecolor('bisque')
# # ax2.set_facecolor('bisque')
# # ax3.set_facecolor('bisque')
# # ax4.set_facecolor('bisque')
# # ax5.set_facecolor('bisque')
# # ax6.set_facecolor('bisque')
# ax1.set_axis_bgcolor('blanchedalmond')
# ax2.set_axis_bgcolor('blanchedalmond')
# ax3.set_axis_bgcolor('blanchedalmond')
# ax4.set_axis_bgcolor('blanchedalmond')
# ax5.set_axis_bgcolor('blanchedalmond')
# ax6.set_axis_bgcolor('blanchedalmond')

# ax1.set_ylabel('Number of calculations')
# ax4.set_ylabel('Number of calculations')
# #plt.savefig("K_max_all_N.png", dpi=150)
# save_fig_size('K_max_all_N',9,5,'pdf')
# #plt.show()

#f, ((ax1, ax2, ax3), (ax4, ax5, ax6),) = plt.subplots(2, 3,sharex='col', sharey='row')

# ax = subplot(111,axisbg='blanchedalmond')
# data = np.loadtxt('N_20_summary.dat')
# sns.swarmplot(x=data[:,1],y=data[:,2],size=1, palette=color_palette,edgecolor='none')
# plot([-5,25],[80,80],'k--',linewidth=0.75)
# x =[2,5,10,15,20]
# labels = [ '$F_1$','$F_2$','$F_3$','$F_4$','$F_5$','$F_6$']
# ax.set_xticklabels(labels)
# plt.yticks(np.arange(0, 160, 40.0))
# plt.ylim(-20,140)
# plt.ylabel('Number of calculations')
# plt.xlabel('Feature sets')
# save_fig_size('G_min_N_20',3,2.5,'pdf')

color_palette =['blue','gray','dodgerblue','red']

ax = subplot(111)
data = np.loadtxt('N_10_BMA_summary.dat')
sns.swarmplot(x=data[:,1],y=data[:,2],size=1, palette=color_palette,edgecolor='none')
plot([-5,25],[80,80],'k--',linewidth=0.75)
x =[2,5,10,15,20]
labels = [ '$F_2$','$F_6$','BMA$_1$','BMA$_2$']
ax.set_xticklabels(labels)
plt.yticks(np.arange(0, 160, 40.0))
plt.ylim(-20,140)
ax.set_facecolor('blanchedalmond')
plt.xlabel('Feature sets')
plt.ylabel('Number of calculations')
save_fig_size('G_min_N_10_BMA_violinplot',3,2.5,'pdf')