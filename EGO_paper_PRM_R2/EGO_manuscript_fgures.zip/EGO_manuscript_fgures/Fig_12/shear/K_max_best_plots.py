#! /usr/bin/env python
"""
 Module for running and control of EGO
"""

__author__ = "Anjana Talapatra (anjanatalapatra@tamu.edu)"
__version__ = "0.1$"
__date__ = "$Date: May 2016 $"
__copyright__ = "Copyright (c) 2016 Anjana Talapatra"
__license__ = "Python"


import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from matplotlib import colors
from plot_settings import *

font = {'family' : 'sans-serif',
        'weight' : 'bold',
        'size'   : 12}

matplotlib.rc('font', **font)
matplotlib.rcParams['axes.linewidth'] = 0.1

label_size = 12
mpl.rcParams['xtick.labelsize'] = label_size 
mpl.rcParams['ytick.labelsize'] = label_size

init_sets = [10]# [2,5,10,15,20]
new_x =[2,12,22,32,42,52,62,72,82]
x= [0,5,10,15,20,25,30,35,40]
#sns.set_style("white")

for i in init_sets:
	plt.figure()
	new_x =[i,i+10,i+20,i+30,i+40,i+50,i+60,i+70,i+80]
	x= [0,5,10,15,20,25,30,35,40]
	data_2 = np.loadtxt('N{}_F2.dat'.format(str(i)))
	data_2a = np.loadtxt('N{}_F8.dat'.format(str(i)))
	data_2b = np.loadtxt('N{}_F9.dat'.format(str(i)))
	data_2c = np.loadtxt('N{}_F10.dat'.format(str(i)))
	data_2d = np.loadtxt('N{}_F11.dat'.format(str(i)))
	
	p2=sns.tsplot(data=data_2, color="b",markersize=3,markeredgecolor='none')
	p2a=sns.tsplot(data=data_2a, color="cadetblue",marker="s",markersize=3,markeredgecolor='none')
	p2b=sns.tsplot(data=data_2b, color ='turquoise',marker="o",markersize=3,markeredgecolor='none')
	p2c=sns.tsplot(data=data_2c, color="cornflowerblue",marker="v",markersize=3,markeredgecolor='none')
	p2d=sns.tsplot(data=data_2d, color="steelblue",marker="d",markersize=3,markeredgecolor='none')
	#sns.set_style("white")
	plt.xticks(x,new_x)
	plt.xlabel('Number of Calculations')
	plt.ylabel('Minimum Shear Modulus (GPa)')
	plt.ylim(5,50)
	plt.xlim(0,38)

	
	
	line2 = plt.Line2D((0,1),(0,0), color="b",markersize=3,markeredgecolor='none')
	line2a = plt.Line2D((0,1),(0,0), color="cadetblue",marker="s",markersize=3,markeredgecolor='none')
	line2b = plt.Line2D((0,1),(0,0), color="turquoise",marker="o",markersize=3,markeredgecolor='none')
	line2c = plt.Line2D((0,1),(0,0), color ='cornflowerblue',marker="v",markersize=3,markeredgecolor='none')
	line2d = plt.Line2D((0,1),(0,0), color="steelblue",marker="d",markersize=3,markeredgecolor='none')
	plt.plot([0,38],[10.38,10.38],'k--',linewidth=0.5)
	ax = plt.gca()
	#ax.set_facecolor('blanchedalmond')
	ax.set_facecolor('blanchedalmond')
	handles, labels = ax.get_legend_handles_labels()
	#plt.legend([p1,p2,p3,p4,p5,p6,pall],['F1','F2','F3','F4','F5','F6','all F'], ncol=2, loc=1)
	first_legend =plt.legend([handle for i,handle in enumerate(handles) if i in display]+[line2a,line2b,line2,line2c,line2d],[label for i,label in enumerate(labels) if i in display]+['F2$_a$','F2$_b$','F2','F2$_c$','F2$_d$'],ncol=2,loc=1,fontsize=10)
	#ax = plt.gca().add_artist(first_legend)
	#plt.legend([handle for i,handle in enumerate(handles) if i in display]+[line7,line8],[label for i,label in enumerate(labels) if i in display]+['BMA-first order','BMA-second order'],ncol=1,loc=2)
	first_legend.get_frame().set_linewidth(0)
	first_legend.get_frame().set_facecolor('blanchedalmond')
	save_fig_size('N_{}_min_G_combo_F2'.format(str(i)),3,2.5,'pdf')



