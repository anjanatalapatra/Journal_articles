#! /usr/bin/env python
"""
 Module for running and control of EGO
"""

__author__ = "Anjana Talapatra (anjanatalapatra@tamu.edu)"
__version__ = "0.1$"
__date__ = "$Date: May 2016 $"
__copyright__ = "Copyright (c) 2016 Anjana Talapatra"
__license__ = "Python"


import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from plot_settings import *
import matplotlib

font = {'family': 'sans-serif',
        'weight': 'bold',
        'size': 12}


label_size = 12
mpl.rcParams['xtick.labelsize'] = label_size
mpl.rcParams['ytick.labelsize'] = label_size


init_sets = [10]
new_x = [2, 12, 22, 32, 42, 52, 62, 72, 82]
x = [0, 5, 10, 15, 20, 25, 30, 35, 40]
sns.set_style("white")

matplotlib.rc('font', **font)
matplotlib.rcParams['axes.linewidth'] = 0.1

for i in init_sets:

    new_x = [i, i + 10, i + 20, i + 30, i + 40, i + 50, i + 60, i + 70, i + 80]
    x = [0, 5, 10, 15, 20, 25, 30, 35, 40]
    data_1 = np.loadtxt('N{}_F1.dat'.format(str(i)))
    data_2 = np.loadtxt('N{}_F2.dat'.format(str(i)))
    data_3 = np.loadtxt('N{}_F3.dat'.format(str(i)))
    data_4 = np.loadtxt('N{}_F4.dat'.format(str(i)))
    data_5 = np.loadtxt('N{}_F5.dat'.format(str(i)))
    data_6 = np.loadtxt('N{}_F6.dat'.format(str(i)))
    data_fo = np.loadtxt('N{}_max_fo.dat'.format(str(i)))
    data_so = np.loadtxt('N{}_max_so.dat'.format(str(i)))

    plt.figure()
    p1 = sns.tsplot(data=data_1, linewidth=2.0, linestyle='-', color="g")
    p2 = sns.tsplot(data=data_2, linewidth=2.0, linestyle='--', color="b")
    p3 = sns.tsplot(data=data_3, linewidth=2.0, marker='v',
                    color="magenta", markersize=3)
    # ,marker="d",markersize=6,linewidth=1.0,markeredgecolor='none')
    p4 = sns.tsplot(data=data_4, linewidth=2.0, marker='p',
                    color='purple', markersize=3)
    # ,marker="v",markersize=8,linewidth=1.0,markeredgecolor='none')
    p5 = sns.tsplot(data=data_5, linewidth=2.0, marker='o',
                    color="darkorange", markersize=3)
    # ,marker="*",markersize=10,linewidth=1.0,markeredgecolor='none')
    p6 = sns.tsplot(data=data_6, linewidth=2.0,
                    marker='D', color="gray", markersize=3)
    plt.xticks(x, new_x)
    plt.xlabel('Number of Calculations')
    plt.ylabel('Max Bulk Modulus (GPa)')
    plt.ylim(240, 305)
    plt.xlim(0, 38)

    line1 = plt.Line2D((0, 1), (0, 0), linewidth=2.0, linestyle='-', color="g")
    line2 = plt.Line2D((0, 1), (0, 0), linewidth=2.0,
                       linestyle='--', color="b")
    line3 = plt.Line2D((0, 1), (0, 0), linewidth=2.0,
                       marker='v', color="magenta", markersize=3)
    line4 = plt.Line2D((0, 1), (0, 0), linewidth=2.0,
                       marker='p', color='purple', markersize=3)
    line5 = plt.Line2D((0, 1), (0, 0), linewidth=2.0,
                       marker='o', color="darkorange", markersize=3)
    line6 = plt.Line2D((0, 1), (0, 0), linewidth=2.0,
                       marker='D', color="gray", markersize=3)
    plt.plot([0, 38], [300, 300], 'k--', linewidth=1.0)
    ax = plt.gca()
    #ax.set_axis_bgcolor('blanchedalmond')
    ax.set_facecolor('blanchedalmond')
    plt.yticks(np.arange(240, 320, 20.0))
    #matplotlib.rcParams['axes.linewidth'] = 0.1
    handles, labels = ax.get_legend_handles_labels()
    first_legend = plt.legend([handle for i, handle in enumerate(handles) if i in display]+[line1, line2, line3, line4, line5, line6], [
                              label for i, label in enumerate(labels) if i in display]+['$F_1$', '$F_2$', '$F_3$', '$F_4$', '$F_5$', '$F_6$'], ncol=2, loc=4, fontsize=10)
    #first_legend =plt.legend([handle for i,handle in enumerate(handles) if i in display]+[p1,p2,p3,p4,p5,p6],[label for i,label in enumerate(labels) if i in display]+['F1','F2','F3','F4','F5','F6'],ncol=2,loc=4,fontsize=10)
    #sns.ax.legend([p1,p2,p3,p4,p5,p6], labels=["F1", "F2","F3", "F4","F5", "F6"])
    # #ax = plt.gca().add_artist(first_legend)
    first_legend.get_frame().set_linewidth(0.1)
    first_legend.get_frame().set_facecolor('antiquewhite')
    save_fig_size('N_{}_K_max_single_models'.format(str(i)), 3, 2.5, 'pdf')

    plt.figure()

    p2 = sns.tsplot(data=data_2, linewidth=2.0, linestyle='--', color="b")
    p6 = sns.tsplot(data=data_6, linewidth=2.0,
                    marker='D', color="gray", markersize=3)
    p7 = sns.tsplot(data=data_fo, color="dodgerblue", marker="h", markersize=3)
    p8 = sns.tsplot(data=data_so, color="r", marker="|", markersize=3)

    # sns.set_style("white")
    #matplotlib.rc('font', **font)
    #matplotlib.rcParams['axes.linewidth'] = 0.1
    plt.xticks(x, new_x)
    plt.xlabel('Number of Calculations')
    plt.ylabel('Max Bulk Modulus (GPa)')
    plt.ylim(220, 305)
    plt.xlim(0, 38)
    line2 = plt.Line2D((0, 1), (0, 0), linewidth=2.0,
                       linestyle='--', color="b")
    line6 = plt.Line2D((0, 1), (0, 0), linewidth=2.0,
                       marker='D', color="gray", markersize=3)
    line7 = plt.Line2D((0, 1), (0, 0), color="dodgerblue",
                       marker="h", markersize=3)
    line8 = plt.Line2D((0, 1), (0, 0), color="r", marker="+", markersize=3)
    plt.plot([0, 38], [300, 300], 'k--', linewidth=1.0)
    ax = plt.gca()
    #ax.set_axis_bgcolor('blanchedalmond')
    ax.set_facecolor('blanchedalmond')
    plt.yticks(np.arange(220, 320, 20.0))
    #matplotlib.rcParams['axes.linewidth'] = 0.1
    handles, labels = ax.get_legend_handles_labels()
    first_legend = plt.legend([handle for i, handle in enumerate(handles) if i in display]+[line2, line6, line7, line8], [label for i, label in enumerate(
        labels) if i in display]+['$F_2$', '$F_6$', 'BMA$_1$', 'BMA$_2$'], ncol=1, loc=4, fontsize=10)  # bbox_to_anchor=(0.05, 0.05)
    first_legend.get_frame().set_linewidth(0.1)
    first_legend.get_frame().set_facecolor('antiquewhite')
    save_fig_size('N_{}_K_max_BMA'.format(str(i)), 3, 2.5, 'pdf')

# init_sets =[2,5,10,15,20]
# new_x =[2,12,22,32,42,52,62,72,82]
# x= [0,5,10,15,20,25,30,35,40]
# #sns.set_style("white")


# data_2 = np.loadtxt('N2_F2.dat')
# data_5 = np.loadtxt('N5_F2.dat')
# data_10 = np.loadtxt('N10_F2.dat')
# data_15 = np.loadtxt('N15_F2.dat')
# data_20 = np.loadtxt('N20_F2.dat')

# data2=[]
# data2_ravg =[]
# for i in range(40):
# 	for j in range(len(data_2)):
#   		data2_ravg.append(data_2[j][i])
# 	data2.append(np.average(data2_ravg))
# 	data2_ravg =[]


# data5=[]
# data5_ravg =[]
# for i in range(40):
# 	for j in range(len(data_5)):
#   		data5_ravg.append(data_5[j][i])
# 	data5.append(np.average(data5_ravg))
# 	data5_ravg =[]

# data10=[]
# data10_ravg =[]
# for i in range(40):
# 	for j in range(len(data_10)):
#   		data10_ravg.append(data_10[j][i])
# 	data10.append(np.average(data10_ravg))
# 	data10_ravg =[]

# data15=[]
# data15_ravg =[]
# for i in range(40):
# 	for j in range(len(data_15)):
#   		data15_ravg.append(data_15[j][i])
# 	data15.append(np.average(data15_ravg))
# 	data15_ravg =[]

# data20=[]
# data20_ravg =[]
# for i in range(40):
# 	for j in range(len(data_20)):
#   		data20_ravg.append(data_20[j][i])
# 	data20.append(np.average(data20_ravg))
# 	data20_ravg =[]

# x = np.linspace(0,39,40)

# plt.plot(2*x+2, data2, 'b-o')
# plt.plot(2*x+5, data5, 'g-o')
# plt.plot(2*x+10, data10, 'r-o')
# plt.plot(2*x+15, data15, 'c-o')
# plt.plot(2*x+20, data20, 'm-o')
# plt.ylim(250,305)
# plt.xlim(0,80)

# #plt.show()

# for i in range(40):
# 	if data20[i] > 299:
# 		print i
# 		break
