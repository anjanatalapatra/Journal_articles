from matplotlib import pyplot as plt
import numpy as np
import matplotlib
from plot_settings import *
from matplotlib import colors

font = {'family' : 'sans-serif',
        'weight' : 'bold',
        'size'   : 12}

matplotlib.rc('font', **font)
matplotlib.rcParams['axes.linewidth'] = 0.1

label_size = 12
mpl.rcParams['xtick.labelsize'] = label_size 
mpl.rcParams['ytick.labelsize'] = label_size

def pareto_frontier(Xs, Ys, maxX = True, maxY = True):
    index_list = np.linspace(1,len(Xs),len(Xs))
# Sort the list in either ascending or descending order of X
    myList = sorted([[Xs[i], Ys[i],index_list[i]] for i in range(len(Xs))], reverse=maxX)
# Start the Pareto frontier with the first value in the sorted list
    p_front = [myList[0]]
# Loop through the sorted list
    for pair in myList[1:]:
        if maxY:
            if pair[1] >= p_front[-1][1]: # Look for higher values of
                p_front.append(pair) # and add them to the Pareto frontier
        else:
            if pair[1] <= p_front[-1][1]: # Look for lower values of
                p_front.append(pair) # and add them to the Pareto frontier
# Turn resulting pairs back into a list of Xs and Ys
    p_frontX = [pair[0] for pair in p_front]
    p_frontY = [pair[1] for pair in p_front]
    p_index  = [pair[2] for pair in p_front]
    return p_frontX, p_frontY, p_index

data = np.loadtxt('K_G_data.dat')
x = data[:,0]
y = data[:,1]
P_x, P_y, P_Z = pareto_frontier(x,y,maxX = True, maxY = False)

plt.scatter(x, y, s=40,  c="seagreen", alpha=0.5, marker='p',lw = 0)
plt.plot(P_x,P_y,'r--o',label='Pareto-front')
plt.xlabel("Bulk Modulus (GPa)")
plt.ylabel("Shear Modulus (GPa)")
leg =plt.legend(loc=2,fontsize=10)
leg.get_frame().set_facecolor('blanchedalmond')
leg.get_frame().set_edgecolor('blanchedalmond')
ax = plt.gca()
ax.set_facecolor('blanchedalmond')
plt.locator_params(axis='y', nbins=6)
plt.locator_params(axis='x', nbins=6)
save_fig_size('pareto_front',3,2.5,'pdf')
#plt.show()
	