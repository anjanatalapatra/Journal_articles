#! /usr/bin/env python
"""
 Module for running and control of EGO
"""

__author__ = "Anjana Talapatra (anjanatalapatra@tamu.edu)"
__version__ = "0.1$"
__date__ = "$Date: May 2016 $"
__copyright__ = "Copyright (c) 2016 Anjana Talapatra"
__license__ = "Python"


import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from matplotlib import colors
from plot_settings import *

font = {'family': 'sans-serif',
        'weight': 'bold',
        'size': 12}

matplotlib.rc('font', **font)
matplotlib.rcParams['axes.linewidth'] = 0.1

label_size = 12
mpl.rcParams['xtick.labelsize'] = label_size
mpl.rcParams['ytick.labelsize'] = label_size

init_sets = [2, 5, 10, 15, 20]
new_x = [2, 12, 22, 32, 42, 52, 62, 72, 82]
x = [0, 5, 10, 15, 20, 25, 30, 35, 40]
# sns.set_style("white")

init_sets = [10]#[2, 5, 10, 15, 20]
new_x = [2, 12, 22, 32, 42, 52, 62, 72, 82]
x = [0, 5, 10, 15, 20, 25, 30, 35, 40]
#sns.set_style("white")

for i in init_sets:

    new_x = [i, i + 10, i + 20, i + 30, i + 40, i + 50, i + 60, i + 70, i + 80]
    x = [0, 5, 10, 15, 20, 25, 30, 35, 40]
    data_1 = np.loadtxt('N{}_F1.dat'.format(str(i)))
    data_2 = np.loadtxt('N{}_F2.dat'.format(str(i)))
    data_3 = np.loadtxt('N{}_F3.dat'.format(str(i)))
    data_4 = np.loadtxt('N{}_F4.dat'.format(str(i)))
    data_5 = np.loadtxt('N{}_F5.dat'.format(str(i)))
    data_6 = np.loadtxt('N{}_F6.dat'.format(str(i)))
    data_all = np.loadtxt('N{}_F7.dat'.format(str(i)))
    data_fo = np.loadtxt('N{}_max_fo.dat'.format(str(i)))
    data_so = np.loadtxt('N{}_max_so.dat'.format(str(i)))
    # plt.figure()
    # p1=sns.tsplot(data=data_1,linewidth=2.0,linestyle='-', color="g")#,marker="o",markersize=6,linewidth=1.0,markeredgecolor='none')
    # p2=sns.tsplot(data=data_2,linewidth=2.0, linestyle='--', color="b")#,marker="s",markersize=6,linewidth=1.0,markeredgecolor='none')
    # p3=sns.tsplot(data=data_3,linewidth=2.0, marker='v',color="magenta",markersize=3)#,marker="p",markersize=6,linewidth=1.0,markeredgecolor='none')
    # p4=sns.tsplot(data=data_4,linewidth=2.0, marker='p',color ='purple',markersize=3)#,marker="d",markersize=6,linewidth=1.0,markeredgecolor='none')
    # p5=sns.tsplot(data=data_5,linewidth=2.0, marker='o',color="darkorange",markersize=3)#,marker="v",markersize=8,linewidth=1.0,markeredgecolor='none')
    # p6=sns.tsplot(data=data_6,linewidth=2.0, marker='D',color="gray",markersize=3)#,marker="*",markersize=10,linewidth=1.0,markeredgecolor='none')
    # plt.xticks(x,new_x)
    # plt.xlabel('Number of Calculations')
    # plt.ylabel('Max Bulk Modulus (GPa)')
    # plt.ylim(0,8)
    # plt.xlim(0,38)

    # pareto_data = np.concatenate(
    #     (data_1[:, 39], data_2[:, 39], data_3[:, 39], data_4[:, 39], data_5[:, 39], data_6[:, 39]), axis=0)

    # pareto_x = np.concatenate((np.ones(len(data_1[:, 39])), 2 * np.ones(len(data_2[:, 39])), 3 * np.ones(len(
    #     data_3[:, 39])), 4 * np.ones(len(data_4[:, 39])), 5 * np.ones(len(data_5[:, 39])), 6 * np.ones(len(data_6[:, 39]))), axis=0)
    #,3*np.ones(len(data_3[:,39])),4*np.ones(len(data_4[:,39])),5*np.ones(len(data_5[:,39])),6*(len(data_6[:,39]))
    # pareto_data = np.concatenate(
    #     (data_1[:, 39], data_2[:, 39], data_fo[:, 39], data_so[:, 39]), axis=0)

    # pareto_x = np.concatenate((np.ones(len(data_1[:, 39])), 2 * np.ones(len(data_2[:, 39])), 7 * np.ones(len(
    #     data_fo[:, 39])), 8 * np.ones(len(data_so[:, 39]))), axis=0)
    # #,3*np.ones(len(data_3[:,39])),4*np.ones(len(data_4[:,39])),5*np.ones(len(data_5[:,39])),6*(len(data_6[:,39]))
    # # color_palette = ['green', 'blue', 'saddlebrown',
    # #                  'purple', 'darkorange', 'gray']
    # color_palette = ['green', 'blue', 'dodgerblue',
    #                  'red']
    # ax = subplot(111)
    # sns.violinplot(x=pareto_x, y=pareto_data,
    #                palette=color_palette, linewidth=0.5)
    # # plot([-5,25],[80,80],'k--',linewidth=0.75)
    # x = [2, 5, 10, 15, 20]
    # #labels = ['$F_1$', '$F_2$', '$F_3$', '$F_4$', '$F_5$', '$F_6$']
    # labels = ['$F_1$', '$F_2$', '${BMA}_1$', '${BMA}_2$']
    # ax.set_xticklabels(labels)
    # # plt.yticks(np.arange(0, 160, 40.0))
    # # plt.ylim(-20,140)
    # plt.ylabel('Pareto points found')
    # plt.xlabel('Feature sets')
    # ax.set_facecolor('blanchedalmond')
    # matplotlib.rcParams['axes.linewidth'] = 0.1
    # save_fig_size('Pareto_BMA_N_{}'.format(str(i)), 3, 2.5, 'pdf')

    # line1 = plt.Line2D((0,1),(0,0), linewidth=2.0,linestyle='-', color="g")
    # line2 = plt.Line2D((0,1),(0,0), linewidth=2.0, linestyle='--', color="b")
    # line3 = plt.Line2D((0,1),(0,0), linewidth=2.0, marker='v',color="magenta",markersize=3)
    # line4 = plt.Line2D((0,1),(0,0), linewidth=2.0, marker='p',color ='purple',markersize=3)
    # line5 = plt.Line2D((0,1),(0,0), linewidth=2.0, marker='o',color="darkorange",markersize=3)
    # line6 = plt.Line2D((0,1),(0,0), linewidth=2.0, marker='D',color="gray",markersize=3)

    # plt.plot([0,38],[10,10],'k--',linewidth=1.0)
    # ax = plt.gca()
    # ax.set_facecolor('blanchedalmond')
    # #plt.yticks(np.arange(240, 320, 20.0))
    # matplotlib.rcParams['axes.linewidth'] = 0.1
    # handles, labels = ax.get_legend_handles_labels()
    # first_legend =plt.legend([handle for i,handle in enumerate(handles) if i in display]+[line1,line2,line3,line4,line5,line6],[label for i,label in enumerate(labels) if i in display]+['$F_1$','$F_2$','$F_3$','$F_4$','$F_5$','$F_6$'],ncol=2,loc=2,fontsize=10)
    # #first_legend =plt.legend([handle for i,handle in enumerate(handles) if i in display]+[p1,p2,p3,p4,p5,p6],[label for i,label in enumerate(labels) if i in display]+['F1','F2','F3','F4','F5','F6'],ncol=2,loc=4,fontsize=10)
    # #sns.ax.legend([p1,p2,p3,p4,p5,p6], labels=["F1", "F2","F3", "F4","F5", "F6"])
    # # #ax = plt.gca().add_artist(first_legend)
    # first_legend.get_frame().set_linewidth(0.1)
    # first_legend.get_frame().set_facecolor('antiquewhite')
    # save_fig_size('N_{}_K_max_single_models'.format(str(i)),3,2.5,'pdf')

    # plt.figure()
    # y = np.zeros((4, 40))
    # for j in range(40):
    #     y[0][j] = np.average(data_1[:, j])
    #     y[1][j] = np.average(data_2[:, j])
    #     y[2][j] = np.average(data_fo[:, j])
    #     y[3][j] = np.average(data_so[:, j])

    # x = np.linspace(0, 40, 40)
    # new_x = [i, i + 10, i + 20, i + 30, i + 40, i + 50, i + 60, i + 70, i + 80]
    # old_x = [0, 5, 10, 15, 20, 25, 30, 35, 40]
    # ax = plt.subplot(111)
    # plot(x, y[1], 'b--', label="F$_2$", linewidth=2,
    #      markersize=4, markeredgecolor='None')
    # #ax.fill_between(x,0,y[1], facecolor='b', alpha=0.8)
    # plot(x, y[3], 'r+', label="BMA$_2$", linewidth=2,
    #      markersize=4, markeredgecolor='None')
    # #ax.fill_between(x,0,y[3], facecolor='r', alpha=0.8)
    # plot(x, y[2], color='dodgerblue', linestyle='-', marker='o', label="BMA$_1$",
    #      linewidth=2, markersize=4)
    # #ax.fill_between(x,0,y[2], facecolor='dodgerblue', alpha=0.8)
    # plot(x, y[0], 'g-', label="F$_1$", linewidth=2,
    #      markersize=4)
    # #ax.fill_between(x,0,y[0], facecolor='g', alpha=0.8)
    # # ax.bar(x, y[1],width=0.6,color='b',align='center',linewidth=0,label="F$_1$")
    # # ax.bar(x, y[3],width=0.6,color='r',align='center',linewidth=0,label="BMA$_2$")
    # # ax.bar(x, y[2],width=0.6,color='dodgerblue',align='center',linewidth=0,label="BMA$_1$")
    # # ax.bar(x, y[0],width=0.6,color='g',align='center',linewidth=0,label="F$_2$")
    # handles, labels = ax.get_legend_handles_labels()
    # import operator
    # hl = sorted(zip(handles, labels),
    #             key=operator.itemgetter(1))
    # handles2, labels2 = zip(*hl)
    # ax.set_facecolor('blanchedalmond')
    # legend = ax.legend(handles2, labels2, loc=2,
    #                    fontsize=10, ncol=2, frameon=True)
    # legend.get_frame().set_linewidth(0.1)
    # legend.get_frame().set_facecolor('antiquewhite')
    # plt.xticks(old_x, new_x)
    # plt.xlabel('Number of Calculations')
    # plt.ylabel('Number of pareto points')

    # plt.xlim(0, 40 - int(i / 2))
    # print int(i / 2)
    # save_fig_size('N_{}_all_pareto'.format(str(i)), 4, 3, 'pdf')
    plt.figure()
  # matplotlib.rc('font', **font)
  # matplotlib.rcParams['axes.linewidth'] = 0.1

  # label_size = 10
  # mpl.rcParams['xtick.labelsize'] = label_size 
  # mpl.rcParams['ytick.labelsize'] = label_size
    p1=p1=sns.tsplot(data=data_1,linewidth=2.0,linestyle='-', color="g")
    p2=sns.tsplot(data=data_2,linewidth=2.0, linestyle='--', color="b")
    p7=sns.tsplot(data=data_fo,color="dodgerblue",marker="h",markersize=3)
    p8=sns.tsplot(data=data_so,color="r",marker="|",markersize=3)

  #sns.set_style("white")
  #matplotlib.rc('font', **font)
  #matplotlib.rcParams['axes.linewidth'] = 0.1
    plt.xticks(x,new_x)
    plt.xlabel('Number of Calculations')
    plt.ylabel('Number of Pareto Points')
    plt.ylim(0,10)
    plt.xlim(0,38)
    line1 = plt.Line2D((0,1),(0,0), linewidth=2.0,linestyle='-', color="g")
    line2 = plt.Line2D((0,1),(0,0), linewidth=2.0, linestyle='--', color="b")
    line7 = plt.Line2D((0,1),(0,0), color="dodgerblue",marker="h",markersize=3)
    line8 = plt.Line2D((0,1),(0,0), color="r",marker="+",markersize=3)
    #plt.plot([0,38],[10,10],'k--',linewidth=1.0)
    ax = plt.gca()
    ax.set_facecolor('blanchedalmond')
    #plt.yticks(np.arange(220, 320, 20.0))
    matplotlib.rcParams['axes.linewidth'] = 0.1
    handles, labels = ax.get_legend_handles_labels()
    first_legend=plt.legend([handle for i,handle in enumerate(handles) if i in display]+[line1,line2,line7,line8],[label for i,label in enumerate(labels) if i in display]+['$F_1$','$F_2$','BMA$_1$','BMA$_2$'],ncol=2,loc=2,fontsize=10,frameon=True) #bbox_to_anchor=(0.05, 0.05)
    first_legend.get_frame().set_linewidth(0)
    first_legend.get_frame().set_facecolor('blanchedalmond')
    save_fig_size('N_{}_multi_pareto'.format(str(i)),3,2.5,'pdf')


# ax = subplot(111, axisbg='blanchedalmond')
# data = np.loadtxt('N_20_summary.dat')
# sns.swarmplot(x=data[:, 1], y=data[:, 2], size=1,
#               palette=color_palette, edgecolor='none')
# plot([-5, 25], [80, 80], 'k--', linewidth=0.75)
# x = [2, 5, 10, 15, 20]
# labels = ['$F_1$', '$F_2$', '$F_3$', '$F_4$', '$F_5$', '$F_6$']
# ax.set_xticklabels(labels)
# plt.yticks(np.arange(0, 160, 40.0))
# plt.ylim(-20, 140)
# plt.ylabel('Number of calculations')
# plt.xlabel('Feature sets')
# save_fig_size('K_max_N_20', 3, 2.5, 'pdf')
