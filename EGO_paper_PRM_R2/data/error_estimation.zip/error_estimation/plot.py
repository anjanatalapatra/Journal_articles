from matplotlib import pyplot as plt
import numpy as np
import matplotlib
from plot_settings import *
from matplotlib import colors
import json

font = {'family': 'sans-serif',
        'weight': 'bold',
        'size': 10}

matplotlib.rc('font', **font)
matplotlib.rcParams['axes.linewidth'] = 0.1

label_size = 10
mpl.rcParams['xtick.labelsize'] = label_size
mpl.rcParams['ytick.labelsize'] = label_size

data = np.loadtxt('output_data.dat')
x = data[:, 0]
calc_data = np.loadtxt('excluded_list.dat')


F1 = json.load(open('final_prediction_F1.json'))[0]
F1_excl = json.load(open('excluded_list_F1.json'))[0]
F1_excl = [int(i) for i in F1_excl]

x_F1 = []
y_F1 = []

for i in range(len(F1_excl)):
        x_F1.append(x[F1_excl[i] - 1])
        y_F1.append(F1[F1_excl[i] - 1])

plt.figure()
plt.scatter(x, F1, s=40, c="salmon", alpha=0.5, marker='p',
            edgecolors='k', lw=0.1, label='Out of sample')
plt.scatter(x_F1, y_F1, s=40, c="dodgerblue", alpha=0.5, marker='p',
            edgecolors='k', lw=0.1, label='In sample')


plt.xlabel("Bulk modulus from DFT (GPa)")
plt.ylabel("Predicted Bulk modulus (GPa)")
leg = plt.legend(loc=0, fontsize=6)
leg.get_frame().set_facecolor('white')
leg.get_frame().set_edgecolor('white')
ax = plt.gca()
plt.ylim(0, 325)
plt.xlim(0, 325)
plt.plot([0, 325], [0, 305], 'g--', linewidth=0.4)
plt.plot([0, 325], [max(x), max(x)], '--', color="dodgerblue", linewidth=0.6)
plt.plot([0, 325], [max(F1), max(F1)], '--', color="salmon", linewidth=0.6)
save_fig_size('F1_error', 3, 2.5, 'pdf')

F2 = json.load(open('final_prediction_F2.json'))[0]
F2_excl = json.load(open('excluded_list_F2.json'))[0]
F2_excl = [int(i) for i in F2_excl]

x_F2 = []
y_F2 = []

for i in range(len(F2_excl)):
        x_F2.append(x[F2_excl[i] - 1])
        y_F2.append(F2[F2_excl[i] - 1])

plt.figure()
y_values_masked = np.ma.masked_where(F2 < 0 , F2)
plt.scatter(x, F2, s=40, c="seagreen", alpha=0.5, marker='p',
            edgecolors='k', lw=0.1, label='Out of sample')
plt.scatter(x_F2, y_F2, s=40, c="dodgerblue", alpha=0.5, marker='p',
            edgecolors='k', lw=0.1, label='In sample')


plt.xlabel("Bulk modulus from DFT (GPa)")
plt.ylabel("Predicted Bulk modulus (GPa)")

ax = plt.gca()
plt.ylim(0, 325)
plt.xlim(0, 325)
plt.plot([0, 325], [0, 305], 'g--', linewidth=0.4)
plt.plot([0, 325], [max(x), max(x)], '--', color="red", linewidth=0.6, label='Max K from DFT')
plt.plot([0, 325], [max(F2), max(F2)], '--', color="k", linewidth=0.6, label='Max K Predicted')
leg = plt.legend(loc=0, fontsize=14)
leg.get_frame().set_facecolor('white')
leg.get_frame().set_edgecolor('white')
save_fig_size('F2_error', 6, 4.5, 'pdf')


F3 = json.load(open('final_prediction_F3.json'))[0]
F3_excl = json.load(open('excluded_list_F3.json'))[0]
F3_excl = [int(i) for i in F3_excl]

x_F3 = []
y_F3 = []

for i in range(len(F3_excl)):
        x_F3.append(x[F3_excl[i] - 1])
        y_F3.append(F3[F3_excl[i] - 1])
y_values_masked = np.ma.masked_where(F3 < 5, F3)
print y_values_masked
plt.figure()
plt.scatter(x, y_values_masked, s=40, c="salmon", alpha=0.5, marker='p',
            edgecolors='k', lw=0.1, label='Out of sample')
plt.scatter(x_F3, y_F3, s=40, c="dodgerblue", alpha=0.5, marker='p',
            edgecolors='k', lw=0.1, label='In sample')


plt.xlabel("Bulk modulus from DFT (GPa)")
plt.ylabel("Predicted Bulk modulus (GPa)")
leg = plt.legend(loc=0, fontsize=6)
leg.get_frame().set_facecolor('white')
leg.get_frame().set_edgecolor('white')
ax = plt.gca()
plt.ylim(0, 325)
plt.xlim(0, 325)
plt.plot([0, 325], [0, 305], 'g--', linewidth=0.4)
plt.plot([0, 325], [max(x), max(x)], '--', color="dodgerblue", linewidth=0.6)
plt.plot([0, 325], [max(F3), max(F3)], '--', color="salmon", linewidth=0.6)
save_fig_size('F3_error', 3, 2.5, 'pdf')


F4 = json.load(open('final_prediction_F4.json'))[0]
F4_excl = json.load(open('excluded_list_F4.json'))[0]
F4_excl = [int(i) for i in F4_excl]

x_F4 = []
y_F4 = []

for i in range(len(F4_excl)):
        x_F4.append(x[F4_excl[i] - 1])
        y_F4.append(F4[F4_excl[i] - 1])

plt.figure()
plt.scatter(x, F4, s=40, c="salmon", alpha=0.5, marker='p',
            edgecolors='k', lw=0.1, label='Out of sample')
plt.scatter(x_F4, y_F4, s=40, c="dodgerblue", alpha=0.5, marker='p',
            edgecolors='k', lw=0.1, label='In sample')


plt.xlabel("Bulk modulus from DFT (GPa)")
plt.ylabel("Predicted Bulk modulus (GPa)")
leg = plt.legend(loc=0, fontsize=6)
leg.get_frame().set_facecolor('white')
leg.get_frame().set_edgecolor('white')
ax = plt.gca()
plt.ylim(0, 325)
plt.xlim(0, 325)
plt.plot([0, 325], [0, 305], 'g--', linewidth=0.4)
plt.plot([0, 325], [max(x), max(x)], '--', color="dodgerblue", linewidth=0.6)
plt.plot([0, 325], [max(F4), max(F4)], '--', color="salmon", linewidth=0.6)
save_fig_size('F4_error', 3, 2.5, 'pdf')

F5 = json.load(open('final_prediction_F5.json'))[0]
F5_excl = json.load(open('excluded_list_F5.json'))[0]
F5_excl = [int(i) for i in F5_excl]

x_F5 = []
y_F5 = []

for i in range(len(F5_excl)):
        x_F5.append(x[F5_excl[i] - 1])
        y_F5.append(F5[F5_excl[i] - 1])

plt.figure()
plt.scatter(x, F5, s=40, c="salmon", alpha=0.5, marker='p',
            edgecolors='k', lw=0.1, label='Out of sample')
plt.scatter(x_F5, y_F5, s=40, c="dodgerblue", alpha=0.5, marker='p',
            edgecolors='k', lw=0.1, label='In sample')


plt.xlabel("Bulk modulus from DFT (GPa)")
plt.ylabel("Predicted Bulk modulus (GPa)")
leg = plt.legend(loc=0, fontsize=6)
leg.get_frame().set_facecolor('white')
leg.get_frame().set_edgecolor('white')
ax = plt.gca()
plt.ylim(0, 325)
plt.xlim(0, 325)
plt.plot([0, 325], [0, 305], 'g--', linewidth=0.4)
plt.plot([0, 325], [max(x), max(x)], '--', color="dodgerblue", linewidth=0.6)
plt.plot([0, 325], [max(F5), max(F5)], '--', color="salmon", linewidth=0.6)
save_fig_size('F5_error', 3, 2.5, 'pdf')


F6 = json.load(open('final_prediction_F6.json'))[0]
F6_excl = json.load(open('excluded_list_F6.json'))[0]
F6_excl = [int(i) for i in F6_excl]

x_F6 = []
y_F6 = []

for i in range(len(F6_excl)):
        x_F6.append(x[F6_excl[i] - 1])
        y_F6.append(F6[F6_excl[i] - 1])

plt.figure()
plt.scatter(x, F6, s=40, c="salmon", alpha=0.5, marker='p',
            edgecolors='k', lw=0.1, label='Out of sample')
plt.scatter(x_F6, y_F6, s=40, c="dodgerblue", alpha=0.5, marker='p',
            edgecolors='k', lw=0.1, label='In sample')


plt.xlabel("Bulk modulus from DFT (GPa)")
plt.ylabel("Predicted Bulk modulus (GPa)")
leg = plt.legend(loc=0, fontsize=6)
leg.get_frame().set_facecolor('white')
leg.get_frame().set_edgecolor('white')
ax = plt.gca()
plt.ylim(0, 325)
plt.xlim(0, 325)
plt.plot([0, 325], [0, 305], 'g--', linewidth=0.4)
plt.plot([0, 325], [max(x), max(x)], '--', color="dodgerblue", linewidth=0.6)
plt.plot([0, 325], [max(F6), max(F6)], '--', color="salmon", linewidth=0.6)
save_fig_size('F6_error', 3, 2.5, 'pdf')

BMA1 = json.load(open('final_prediction_BMA1.json'))[0]
BMA1_excl = json.load(open('excluded_list_BMA1.json'))[0]
BMA1_excl = [int(i) for i in BMA1_excl]

x_BMA1 = []
y_BMA1 = []

for i in range(len(BMA1_excl)):
        x_BMA1.append(x[BMA1_excl[i] - 1])
        y_BMA1.append(F6[BMA1_excl[i] - 1])

plt.figure()
plt.scatter(x, BMA1, s=40, c="salmon", alpha=0.5, marker='p',
            edgecolors='k', lw=0.1, label='Out of sample')
plt.scatter(x_BMA1, y_F6, s=40, c="dodgerblue", alpha=0.5, marker='p',
            edgecolors='k', lw=0.1, label='In sample')


plt.xlabel("Bulk modulus from DFT (GPa)")
plt.ylabel("Predicted Bulk modulus (GPa)")
leg = plt.legend(loc=0, fontsize=6)
leg.get_frame().set_facecolor('white')
leg.get_frame().set_edgecolor('white')
ax = plt.gca()
plt.ylim(0, 325)
plt.xlim(0, 325)
plt.plot([0, 325], [0, 305], 'g--', linewidth=0.4)
plt.plot([0, 325], [max(x), max(x)], '--', color="dodgerblue", linewidth=0.6)
plt.plot([0, 325], [max(BMA1), max(BMA1)], '--', color="salmon", linewidth=0.6)
save_fig_size('BMA1_error', 3, 2.5, 'pdf')



BMA2 = json.load(open('final_prediction_BMA1.json'))[0]
BMA2_excl = json.load(open('excluded_list_BMA1.json'))[0]
BMA2_excl = [int(i) for i in BMA2_excl]

x_BMA2 = []
y_BMA2 = []

for i in range(len(BMA2_excl)):
        x_BMA2.append(x[BMA2_excl[i] - 1])
        y_BMA2.append(F6[BMA2_excl[i] - 1])

plt.figure()
plt.scatter(x, BMA2, s=40, c="salmon", alpha=0.5, marker='p',
            edgecolors='k', lw=0.1, label='Out of sample')
plt.scatter(x_BMA2, y_F6, s=40, c="dodgerblue", alpha=0.5, marker='p',
            edgecolors='k', lw=0.1, label='In sample')


plt.xlabel("Bulk modulus from DFT (GPa)")
plt.ylabel("Predicted Bulk modulus (GPa)")
leg = plt.legend(loc=0, fontsize=6)
leg.get_frame().set_facecolor('white')
leg.get_frame().set_edgecolor('white')
ax = plt.gca()
plt.ylim(0, 325)
plt.xlim(0, 325)
plt.plot([0, 325], [0, 305], 'g--', linewidth=0.4)
plt.plot([0, 325], [max(x), max(x)], '--', color="dodgerblue", linewidth=0.6)
plt.plot([0, 325], [max(BMA1), max(BMA1)], '--', color="salmon", linewidth=0.6)
save_fig_size('BMA2_error', 3, 2.5, 'pdf')
