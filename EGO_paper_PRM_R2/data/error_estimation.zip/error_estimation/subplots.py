from matplotlib import pyplot as plt
import numpy as np
import matplotlib
from plot_settings import *
from matplotlib import colors
import json

font = {'family': 'sans-serif',
        'weight': 'bold',
        'size': 10}

matplotlib.rc('font', **font)
matplotlib.rcParams['axes.linewidth'] = 0.1

label_size = 10
mpl.rcParams['xtick.labelsize'] = label_size
mpl.rcParams['ytick.labelsize'] = label_size

#load data and assign

data = np.loadtxt('output_data.dat')
x = data[:, 0]
calc_data = np.loadtxt('excluded_list.dat')


F1 = json.load(open('final_prediction_F1.json'))[0]
F1_excl = json.load(open('excluded_list_F1.json'))[0]
F1_excl = [int(i)-1 for i in F1_excl]

x_F1 = []
y_F1 = []

for i in range(len(F1_excl)):
        x_F1.append(x[F1_excl[i]])
        y_F1.append(F1[F1_excl[i]])

F2 = json.load(open('final_prediction_F2.json'))[0]
F2_excl = json.load(open('excluded_list_F2.json'))[0]
F2_excl = [int(i)-1 for i in F2_excl]

x_F2 = []
y_F2 = []

for i in range(len(F2_excl)):
        x_F2.append(x[F2_excl[i]])
        y_F2.append(F2[F2_excl[i]])

F3 = json.load(open('final_prediction_F3.json'))[0]
F3_excl = json.load(open('excluded_list_F3.json'))[0]
F3_excl = [int(i)-1 for i in F3_excl]

x_F3 = []
y_F3 = []

for i in range(len(F3_excl)):
        x_F3.append(x[F3_excl[i]])
        y_F3.append(F3[F3_excl[i]])

F4 = json.load(open('final_prediction_F4.json'))[0]
F4_excl = json.load(open('excluded_list_F4.json'))[0]
F4_excl = [int(i)-1 for i in F4_excl]

x_F4 = []
y_F4 = []

for i in range(len(F4_excl)):
        x_F4.append(x[F4_excl[i]])
        y_F4.append(F4[F4_excl[i]])

F5 = json.load(open('final_prediction_F5.json'))[0]
F5_excl = json.load(open('excluded_list_F5.json'))[0]
F5_excl = [int(i)-1 for i in F5_excl]

x_F5 = []
y_F5 = []

for i in range(len(F5_excl)):
        x_F5.append(x[F5_excl[i]])
        y_F5.append(F5[F5_excl[i]])

F6 = json.load(open('final_prediction_F6.json'))[0]
F6_excl = json.load(open('excluded_list_F6.json'))[0]
F6_excl = [int(i)-1 for i in F6_excl]

x_F6 = []
y_F6 = []

for i in range(len(F6_excl)):
        x_F6.append(x[F6_excl[i]])
        y_F6.append(F6[F6_excl[i]])

BMA1 = json.load(open('final_prediction_BMA1.json'))[0]
BMA1_excl = json.load(open('excluded_list_BMA1.json'))[0]
BMA1_excl = [int(i)-1 for i in BMA1_excl]

x_BMA1 = []
y_BMA1 = []

for i in range(len(BMA1_excl)):
        x_BMA1.append(x[BMA1_excl[i]])
        y_BMA1.append(BMA1[BMA1_excl[i]])

BMA2 = json.load(open('final_prediction_BMA2.json'))[0]
BMA2_excl = json.load(open('excluded_list_BMA2.json'))[0]
BMA2_excl = [int(i)-1 for i in BMA2_excl]

x_BMA2 = []
y_BMA2 = []

for i in range(len(BMA2_excl)):
        x_BMA2.append(x[BMA2_excl[i]])
        y_BMA2.append(BMA2[BMA2_excl[i]])

#f, ((ax1, ax2), (ax3, ax4), (ax5, ax6), (ax7, ax8)) = plt.subplots(4, 2, sharex='col', sharey='row')

# fig = plt.figure()
# #ax = fig.add_subplot(111)    # The big subplot
# ax1 = fig.add_subplot(241)
# ax2 = fig.add_subplot(242)
# ax3 = fig.add_subplot(243)
# ax4 = fig.add_subplot(244)
# ax5 = fig.add_subplot(245)
# ax6 = fig.add_subplot(246)
# ax7 = fig.add_subplot(247)
# ax8 = fig.add_subplot(248)

# ax1.scatter(np.delete(x,F1_excl), np.delete(F1,F1_excl), s=40, c="seagreen", alpha=0.5, marker='p',
#             edgecolors='k', lw=0.1, label='Out of sample')
# ax1.scatter(x_F1, y_F1, s=40, c="dodgerblue", alpha=0.5, marker='p',
#             edgecolors='k', lw=0.1, label='In sample')


# #ax1.set_xlabel("Bulk modulus from DFT (GPa)")
# #ax1.set_ylabel("Predicted Bulk modulus (GPa)")
# #leg = plt.legend(loc=0, fontsize=6)
# #leg.get_frame().set_facecolor('white')
# #leg.get_frame().set_edgecolor('white')
# #ax = plt.gca()
# ax1.set_ylim(0, 325)
# ax1.set_xlim(0, 325)
# ax1.plot([0, 325], [0, 305], 'g--', linewidth=0.4)
# ax1.plot([0, 325], [max(x), max(x)], '--', color="red", linewidth=0.6)
# ax1.plot([0, 325], [max(F1), max(F1)], '--', color="k", linewidth=0.6)



# ax2.scatter(np.delete(x,F2_excl), np.delete(F2,F2_excl), s=40, c="seagreen", alpha=0.5, marker='p',
#             edgecolors='k', lw=0.1)
# ax2.scatter(x_F2, y_F2, s=40, c="dodgerblue", alpha=0.5, marker='p',
#             edgecolors='k', lw=0.1)


# #ax2.set_xlabel("Bulk modulus from DFT (GPa)")
# #ax2.set_ylabel("Predicted Bulk modulus (GPa)")
# # leg = ax2.legend(loc=0, fontsize=6)
# # leg.get_frame().set_facecolor('white')
# # leg.get_frame().set_edgecolor('white')
# ax2.set_ylim(0, 325)
# ax2.set_xlim(0, 325)
# ax2.plot([0, 325], [0, 305], 'g--', linewidth=0.4)
# ax2.plot([0, 325], [max(x), max(x)], '--', color="red", linewidth=0.6)
# ax2.plot([0, 325], [max(F2), max(F2)], '--', color="k", linewidth=0.6)

# #y_values_masked = np.ma.masked_where(F3 < 5, F3)
# ax3.scatter(np.delete(x,F3_excl), np.delete(F3,F3_excl), s=40, c="seagreen", alpha=0.5, marker='p',
#             edgecolors='k', lw=0.1)
# ax3.scatter(x_F3, y_F3, s=40, c="dodgerblue", alpha=0.5, marker='p',
#             edgecolors='k', lw=0.1)


# #ax3.set_xlabel("Bulk modulus from DFT (GPa)")
# #ax3.set_ylabel("Predicted Bulk modulus (GPa)")
# ax3.set_ylim(0, 325)
# ax3.set_xlim(0, 325)
# ax3.plot([0, 325], [0, 305], 'g--', linewidth=0.4)
# ax3.plot([0, 325], [max(x), max(x)], '--', color="red", linewidth=0.6)
# ax3.plot([0, 325], [max(F3), max(F3)], '--', color="k", linewidth=0.6)


# ax4.scatter(np.delete(x,F4_excl), np.delete(F4,F4_excl), s=40, c="seagreen", alpha=0.5, marker='p',
#             edgecolors='k', lw=0.1)
# ax4.scatter(x_F4, y_F4, s=40, c="dodgerblue", alpha=0.5, marker='p',
#             edgecolors='k', lw=0.1)


# #ax4.set_xlabel("Bulk modulus from DFT (GPa)")
# #ax4.set_ylabel("Predicted Bulk modulus (GPa)")
# ax4.set_ylim(0, 325)
# ax4.set_xlim(0, 325)
# ax4.plot([0, 325], [0, 305], 'g--', linewidth=0.4)
# ax4.plot([0, 325], [max(x), max(x)], '--', color="red", linewidth=0.6)
# ax4.plot([0, 325], [max(F4), max(F4)], '--', color="k", linewidth=0.6)


# ax5.scatter(np.delete(x,F5_excl), np.delete(F5,F5_excl), s=40, c="seagreen", alpha=0.5, marker='p',
#             edgecolors='k', lw=0.1)
# ax5.scatter(x_F5, y_F5, s=40, c="dodgerblue", alpha=0.5, marker='p',
#             edgecolors='k', lw=0.1)


# #ax5.set_xlabel("Bulk modulus from DFT (GPa)")
# #ax5.set_ylabel("Predicted Bulk modulus (GPa)")
# ax5.set_ylim(0, 325)
# ax5.set_xlim(0, 325)
# ax5.plot([0, 325], [0, 305], 'g--', linewidth=0.4)
# ax5.plot([0, 325], [max(x), max(x)], '--', color="red", linewidth=0.6)
# ax5.plot([0, 325], [max(F5), max(F5)], '--', color="k", linewidth=0.6)



# ax6.scatter(np.delete(x,F6_excl), np.delete(F6,F6_excl), s=40, c="seagreen", alpha=0.5, marker='p',
#             edgecolors='k', lw=0.1)
# ax6.scatter(x_F6, y_F6, s=40, c="dodgerblue", alpha=0.5, marker='p',
#             edgecolors='k', lw=0.1)


# #ax6.set_xlabel("Bulk modulus from DFT (GPa)")
# #ax6.set_ylabel("Predicted Bulk modulus (GPa)")
# ax6.set_ylim(0, 325)
# ax6.set_xlim(0, 325)
# ax6.plot([0, 325], [0, 305], 'g--', linewidth=0.4)
# ax6.plot([0, 325], [max(x), max(x)], '--', color="red", linewidth=0.6)
# ax6.plot([0, 325], [max(F6), max(F6)], '--', color="k", linewidth=0.6)


# ax7.scatter(np.delete(x,BMA1_excl), np.delete(BMA1,BMA1_excl), s=40, c="seagreen", alpha=0.5, marker='p',
#             edgecolors='k', lw=0.1)
# ax7.scatter(x_BMA1, y_BMA1, s=40, c="dodgerblue", alpha=0.5, marker='p',
#             edgecolors='k', lw=0.1)
# for i in range(len(x_BMA1)):
#     print x_BMA1[i],y_BMA1[i]


# #ax7.set_xlabel("Bulk modulus from DFT (GPa)")
# #ax7.set_ylabel("Predicted Bulk modulus (GPa)")
# ax7.set_ylim(0, 325)
# ax7.set_xlim(0, 325)
# ax7.plot([0, 325], [0, 305], 'g--', linewidth=0.4)
# ax7.plot([0, 325], [max(x), max(x)], '--', color="red", linewidth=0.6)
# ax7.plot([0, 325], [max(BMA1), max(BMA1)], '--', color="k", linewidth=0.6)



# ax8.scatter(np.delete(x,BMA2_excl), np.delete(BMA2,BMA2_excl), s=40, c="seagreen", alpha=0.5, marker='p',
#             edgecolors='k', lw=0.1)
# ax8.scatter(x_BMA2, y_BMA2, s=40, c="dodgerblue", alpha=0.5, marker='p',
#             edgecolors='k', lw=0.1)


# #ax8.set_xlabel("Bulk modulus from DFT (GPa)")
# #ax8.set_ylabel("Predicted Bulk modulus (GPa)")
# ax8.set_ylim(0, 325)
# ax8.set_xlim(0, 325)
# ax8.plot([0, 325], [0, 305], 'g--', linewidth=0.4)
# ax8.plot([0, 325], [max(x), max(x)], '--', color="red", linewidth=0.6)
# ax8.plot([0, 325], [max(BMA2), max(BMA2)], '--', color="k", linewidth=0.6)

# #ax.set_xlabel("Bulk modulus from DFT (GPa)")
# #ax.set_ylabel("Predicted Bulk modulus (GPa)")

# #leg = fig.legend(bbox_to_anchor=(1.05, 1), loc=2, borderaxespad=0.)
# #leg.get_frame().set_facecolor('white')
# #leg.get_frame().set_edgecolor('white')
# leg = plt.legend(loc=0, fontsize=6)
# #leg.get_frame().set_facecolor('white')
# #leg.get_frame().set_edgecolor('white')

# #fig.patch.set_visible(False)
# save_fig_size('F1_error_grid', 10, 4.5, 'pdf')

max_K =[]

sigma = [9.524984249989048,8.000398132774633,28.419218403673963,7.21995388618447, 9.962191085850076, 12.610440654867073,14.829556042336366,9.325235854120404]

max_K.append(F1[176])
max_K.append(F2[176])
max_K.append(F3[176])
max_K.append(F4[176])
max_K.append(F5[176])
max_K.append(F6[176])
max_K.append(BMA1[176])
max_K.append(BMA2[176])
#print max_K

ax = subplot(111)
#plt.figure()
max_x = np.linspace(1,8,8)
print max_x
max_all = 300.732*np.ones(8)
#ax.plot(max_x, max_all-max_K,'ro',markersize=10)
print max_all-max_K
plt.bar(max_x, max_K,width=0.5,color='deepskyblue',yerr=sigma)
plt.plot([0,9],[300.732,300.732],'r--',linewidth=0.6)
plt.xlim(0.5,8.5)
plt.xticks(max_x)
#plt.plot([1, 8], [300.732, 300.732], '--', color="red", linewidth=0.6)
#plt.plot(max_x, max_all,'g--',linewidth=1)
#ax.set_xlim(0,9)
labels = ['F$_1$','F$_2$','F$_3$','F$_4$','F$_5$','F$_6$','BMA$_1$','BMA$_2$']

#ax.set_xticklabels(max_x)
ax.set_xticklabels(labels)
plt.xlabel('Feature sets')
plt.ylabel('Bulk Modulus (GPa)')
save_fig_size('error_bar_plot', 4, 2.5, 'pdf')
plt.show()